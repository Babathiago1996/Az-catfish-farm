const http = require("http");

const app = require("./app");
const env = require("./config/env");
const {
  connectDatabase,
  disconnectDatabase
} = require("./config/database");

let server;

const shutdown = async (signal) => {
  console.log(`${signal} received. Starting graceful shutdown...`);

  if (!server) {
    process.exit(0);
  }

  server.close(async (serverError) => {
    if (serverError) {
      console.error(
        `HTTP server shutdown error: ${serverError.message}`
      );

      process.exit(1);
    }

    try {
      await disconnectDatabase();
      process.exit(0);
    } catch (databaseError) {
      console.error(
        `Database shutdown error: ${databaseError.message}`
      );

      process.exit(1);
    }
  });
};

const startServer = async () => {
  try {
    await connectDatabase();

    server = http.createServer(app);

    server.listen(env.port, () => {
      console.log(
        `AZ Fish Farm API running on port ${env.port} in ${env.nodeEnv} mode.`
      );
    });

    server.on("error", (error) => {
      if (error.code === "EADDRINUSE") {
        console.error(`Port ${env.port} is already in use.`);
      } else {
        console.error(`Server error: ${error.message}`);
      }

      process.exit(1);
    });
  } catch (error) {
    console.error(`Unable to start application: ${error.message}`);
    process.exit(1);
  }
};

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));

process.on("unhandledRejection", (reason) => {
  console.error("Unhandled promise rejection:", reason);

  if (server) {
    shutdown("UNHANDLED_REJECTION");
  } else {
    process.exit(1);
  }
});

process.on("uncaughtException", (error) => {
  console.error("Uncaught exception:", error);

  if (server) {
    shutdown("UNCAUGHT_EXCEPTION");
  } else {
    process.exit(1);
  }
});

startServer();