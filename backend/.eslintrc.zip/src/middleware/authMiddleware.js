const Admin = require("../models/Admin");
const { verifyAccessToken } = require("../utils/token");
const asyncHandler = require("../utils/asyncHandler");
const { errorResponse } = require("../utils/apiResponse");

const getBearerToken = (authorizationHeader) => {
  if (!authorizationHeader) {
    return null;
  }

  const [scheme, token] = authorizationHeader.split(" ");

  if (scheme !== "Bearer" || !token) {
    return null;
  }

  return token;
};

const protect = asyncHandler(async (req, res, next) => {
  const token = getBearerToken(req.headers.authorization);

  if (!token) {
    return errorResponse(res, {
      statusCode: 401,
      message: "Authentication is required."
    });
  }

  let decodedToken;

  try {
    decodedToken = verifyAccessToken(token);
  } catch (error) {
    return errorResponse(res, {
      statusCode: 401,
      message:
        error.name === "TokenExpiredError"
          ? "Your session has expired. Please log in again."
          : "Invalid authentication token."
    });
  }

  const admin = await Admin.findById(decodedToken.sub);

  if (!admin || !admin.isActive) {
    return errorResponse(res, {
      statusCode: 401,
      message: "Administrator account is unavailable."
    });
  }

  req.admin = admin;
  req.auth = {
    adminId: admin._id.toString(),
    tokenType: decodedToken.type
  };

  next();
});

module.exports = {
  protect
};