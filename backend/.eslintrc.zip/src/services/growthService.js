const mongoose = require("mongoose");

const GrowthRecord = require("../models/GrowthRecord");
const Pond = require("../models/Pond");
const ActivityLog = require("../models/ActivityLog");

const startOfDay = (value) => {
  const date = new Date(value);
  date.setHours(0, 0, 0, 0);
  return date;
};

const endOfDay = (value) => {
  const date = new Date(value);
  date.setHours(23, 59, 59, 999);
  return date;
};

const calculateBiomass = (
  averageWeight,
  fishCount
) => {
  const weight =
    Number(averageWeight) || 0;

  const count =
    Number(fishCount) || 0;

  /*
   * Average weight is stored in grams.
   * Biomass is returned in kilograms.
   */
  return Number(
    ((weight * count) / 1000).toFixed(3)
  );
};

const calculateGrowthRate = (
  currentWeight,
  previousWeight
) => {
  const current =
    Number(currentWeight) || 0;

  const previous =
    Number(previousWeight) || 0;

  if (previous <= 0) {
    return 0;
  }

  return Number(
    (
      ((current - previous) / previous) *
      100
    ).toFixed(2)
  );
};

const findPreviousRecord = async ({
  pond,
  recordDate,
  excludeId
}) => {
  const filter = {
    pond,
    recordDate: {
      $lt: recordDate
    }
  };

  if (excludeId) {
    filter._id = {
      $ne: excludeId
    };
  }

  return GrowthRecord.findOne(filter)
    .sort({
      recordDate: -1,
      createdAt: -1
    })
    .lean();
};

const recalculatePondGrowthRecords = async (
  pondId
) => {
  const records =
    await GrowthRecord.find({
      pond: pondId
    }).sort({
      recordDate: 1,
      createdAt: 1
    });

  const pond =
    await Pond.findById(pondId);

  if (!pond) {
    return [];
  }

  let previousWeight = null;

  for (const record of records) {
    record.biomass = calculateBiomass(
      record.averageWeight,
      pond.currentFishCount
    );

    record.growthRate =
      previousWeight === null
        ? 0
        : calculateGrowthRate(
            record.averageWeight,
            previousWeight
          );

    await record.save();

    previousWeight =
      Number(record.averageWeight);
  }

  return records;
};

const createGrowthRecord = async ({
  data,
  ipAddress,
  userAgent
}) => {
  if (
    !mongoose.isValidObjectId(data.pond)
  ) {
    return {
      success: false,
      reason: "POND_NOT_FOUND"
    };
  }

  const pond =
    await Pond.findById(data.pond);

  if (!pond) {
    return {
      success: false,
      reason: "POND_NOT_FOUND"
    };
  }

  const duplicate =
    await GrowthRecord.findOne({
      pond: data.pond,
      recordDate: {
        $gte: startOfDay(data.recordDate),
        $lte: endOfDay(data.recordDate)
      }
    });

  if (duplicate) {
    return {
      success: false,
      reason: "DUPLICATE_DATE"
    };
  }

  const previousRecord =
    await findPreviousRecord({
      pond: data.pond,
      recordDate: data.recordDate
    });

  const growthRate =
    previousRecord
      ? calculateGrowthRate(
          data.averageWeight,
          previousRecord.averageWeight
        )
      : 0;

  const biomass = calculateBiomass(
    data.averageWeight,
    pond.currentFishCount
  );

  const record =
    await GrowthRecord.create({
      pond: data.pond,
      recordDate: data.recordDate,
      averageWeight: data.averageWeight,
      sampleSize: data.sampleSize,
      biomass,
      growthRate,
      notes: data.notes || ""
    });

  /*
   * Keep the pond's current average weight
   * synchronized with the latest growth record.
   */
  if (
    !pond.lastGrowthRecordDate ||
    new Date(data.recordDate) >=
      new Date(pond.lastGrowthRecordDate)
  ) {
    pond.currentAverageWeight =
      data.averageWeight;

    pond.lastGrowthRecordDate =
      data.recordDate;

    await pond.save();
  }

  await ActivityLog.create({
    action: "create",
    entityType: "GrowthRecord",
    entityId: record._id,
    description:
      "Weekly fish-growth record was added.",
    metadata: {
      pondId: record.pond,
      averageWeight:
        record.averageWeight,
      sampleSize:
        record.sampleSize,
      biomass: record.biomass,
      growthRate:
        record.growthRate
    },
    ipAddress: ipAddress || "",
    userAgent: userAgent || ""
  });

  return {
    success: true,
    record
  };
};

const listGrowthRecords = async ({
  pond,
  from,
  to,
  page = 1,
  limit = 30
}) => {
  const currentPage = Math.max(
    Number(page) || 1,
    1
  );

  const pageSize = Math.min(
    Math.max(Number(limit) || 30, 1),
    100
  );

  const filter = {};

  if (pond) {
    filter.pond = pond;
  }

  if (from || to) {
    filter.recordDate = {};

    if (from) {
      filter.recordDate.$gte =
        startOfDay(from);
    }

    if (to) {
      filter.recordDate.$lte =
        endOfDay(to);
    }
  }

  const [records, total] =
    await Promise.all([
      GrowthRecord.find(filter)
        .populate(
          "pond",
          "pondName pondNumber pondSize currentFishCount currentAverageWeight"
        )
        .sort({
          recordDate: -1
        })
        .skip((currentPage - 1) * pageSize)
        .limit(pageSize)
        .lean(),

      GrowthRecord.countDocuments(filter)
    ]);

  return {
    records,
    pagination: {
      page: currentPage,
      limit: pageSize,
      total,
      pages: Math.ceil(
        total / pageSize
      )
    }
  };
};

const getGrowthRecordById = async (id) => {
  if (!mongoose.isValidObjectId(id)) {
    return null;
  }

  return GrowthRecord.findById(id)
    .populate(
      "pond",
      "pondName pondNumber pondSize currentFishCount currentAverageWeight"
    )
    .lean();
};

const updateGrowthRecord = async ({
  id,
  data,
  ipAddress,
  userAgent
}) => {
  if (!mongoose.isValidObjectId(id)) {
    return {
      success: false,
      reason: "NOT_FOUND"
    };
  }

  const record =
    await GrowthRecord.findById(id);

  if (!record) {
    return {
      success: false,
      reason: "NOT_FOUND"
    };
  }

  const pondId =
    data.pond || record.pond;

  const pond =
    await Pond.findById(pondId);

  if (!pond) {
    return {
      success: false,
      reason: "POND_NOT_FOUND"
    };
  }

  const recordDate =
    data.recordDate ||
    record.recordDate;

  const duplicate =
    await GrowthRecord.findOne({
      _id: {
        $ne: record._id
      },
      pond: pondId,
      recordDate: {
        $gte: startOfDay(recordDate),
        $lte: endOfDay(recordDate)
      }
    });

  if (duplicate) {
    return {
      success: false,
      reason: "DUPLICATE_DATE"
    };
  }

  if (data.pond !== undefined) {
    record.pond = data.pond;
  }

  if (data.recordDate !== undefined) {
    record.recordDate =
      data.recordDate;
  }

  if (data.averageWeight !== undefined) {
    record.averageWeight =
      data.averageWeight;
  }

  if (data.sampleSize !== undefined) {
    record.sampleSize =
      data.sampleSize;
  }

  if (data.notes !== undefined) {
    record.notes = data.notes;
  }

  record.biomass = calculateBiomass(
    record.averageWeight,
    pond.currentFishCount
  );

  const previousRecord =
    await findPreviousRecord({
      pond: record.pond,
      recordDate: record.recordDate,
      excludeId: record._id
    });

  record.growthRate =
    previousRecord
      ? calculateGrowthRate(
          record.averageWeight,
          previousRecord.averageWeight
        )
      : 0;

  await record.save();

  /*
   * Updating one historical record can alter
   * the growth rate of subsequent records.
   */
  await recalculatePondGrowthRecords(
    record.pond
  );

  const latestRecord =
    await GrowthRecord.findOne({
      pond: record.pond
    })
      .sort({
        recordDate: -1,
        createdAt: -1
      })
      .lean();

  if (latestRecord) {
    pond.currentAverageWeight =
      latestRecord.averageWeight;

    pond.lastGrowthRecordDate =
      latestRecord.recordDate;

    await pond.save();
  }

  await ActivityLog.create({
    action: "update",
    entityType: "GrowthRecord",
    entityId: record._id,
    description:
      "Fish-growth record was updated.",
    metadata: {
      pondId: record.pond,
      averageWeight:
        record.averageWeight,
      sampleSize:
        record.sampleSize
    },
    ipAddress: ipAddress || "",
    userAgent: userAgent || ""
  });

  return {
    success: true,
    record:
      await GrowthRecord.findById(record._id)
        .populate(
          "pond",
          "pondName pondNumber pondSize currentFishCount currentAverageWeight"
        )
        .lean()
  };
};

const getGrowthAnalytics = async ({
  pond,
  from,
  to,
  limit = 100
}) => {
  const filter = {};

  if (pond) {
    filter.pond = pond;
  }

  if (from || to) {
    filter.recordDate = {};

    if (from) {
      filter.recordDate.$gte =
        startOfDay(from);
    }

    if (to) {
      filter.recordDate.$lte =
        endOfDay(to);
    }
  }

  const records =
    await GrowthRecord.find(filter)
      .populate(
        "pond",
        "pondName pondNumber currentFishCount"
      )
      .sort({
        recordDate: 1
      })
      .limit(
        Math.min(
          Math.max(Number(limit) || 100, 1),
          200
        )
      )
      .lean();

  const chartData = records.map(
    (record) => ({
      id: record._id,
      date: record.recordDate,
      pondId: record.pond?._id || null,
      pondName:
        record.pond?.pondName || "Unknown Pond",
      averageWeight:
        Number(record.averageWeight),
      sampleSize:
        Number(record.sampleSize),
      biomass:
        Number(record.biomass || 0),
      growthRate:
        Number(record.growthRate || 0)
    })
  );

  const latestByPond = new Map();

  chartData.forEach((record) => {
    latestByPond.set(
      String(record.pondId),
      record
    );
  });

  const summary = Array.from(
    latestByPond.values()
  ).map((record) => ({
    pondId: record.pondId,
    pondName: record.pondName,
    latestAverageWeight:
      record.averageWeight,
    latestBiomass: record.biomass,
    latestGrowthRate:
      record.growthRate,
    recordDate: record.date
  }));

  return {
    chartData,
    summary,
    totalRecords: chartData.length
  };
};

module.exports = {
  createGrowthRecord,
  listGrowthRecords,
  getGrowthRecordById,
  updateGrowthRecord,
  getGrowthAnalytics,
  calculateBiomass,
  calculateGrowthRate,
  recalculatePondGrowthRecords
};