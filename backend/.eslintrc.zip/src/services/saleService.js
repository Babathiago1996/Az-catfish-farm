const mongoose = require("mongoose");

const Sale = require("../models/Sale");
const Pond = require("../models/Pond");
const ActivityLog = require("../models/ActivityLog");

const generateInvoiceNumber =
  require("../utils/invoiceNumber");

const startOfDay = (value) => {
  const date = new Date(value);
  date.setHours(0, 0, 0, 0);
  return date;
};

const endOfDay = (value) => {
  const date = new Date(value);
  date.setHours(23, 59, 59, 999);
  return date;
};

const calculateTotalAmount = (
  quantitySold,
  averageWeight,
  pricePerKilogram
) => {
  const quantity =
    Number(quantitySold) || 0;

  const weight =
    Number(averageWeight) || 0;

  const price =
    Number(pricePerKilogram) || 0;

  /*
   * Average weight is stored in grams.
   * Convert to kilograms before calculating
   * the sale value.
   */
  const totalWeightKg =
    (quantity * weight) / 1000;

  return Number(
    (totalWeightKg * price).toFixed(2)
  );
};

const calculateTotalWeight = (
  quantitySold,
  averageWeight
) => {
  return Number(
    (
      (Number(quantitySold) *
        Number(averageWeight)) /
      1000
    ).toFixed(3)
  );
};

const normalizePaymentStatus = ({
  paymentStatus,
  amountPaid,
  totalAmount
}) => {
  if (paymentStatus === "cancelled") {
    return "cancelled";
  }

  const paid =
    Number(amountPaid) || 0;

  const total =
    Number(totalAmount) || 0;

  if (paid <= 0) {
    return "pending";
  }

  if (paid >= total) {
    return "paid";
  }

  return "partial";
};

const getPondStock = async (pondId) => {
  if (
    !pondId ||
    !mongoose.isValidObjectId(pondId)
  ) {
    return null;
  }

  return Pond.findById(pondId);
};

const createSale = async ({
  data,
  ipAddress,
  userAgent
}) => {
  let pond = null;

  if (data.pond) {
    pond = await getPondStock(
      data.pond
    );

    if (!pond) {
      return {
        success: false,
        reason: "POND_NOT_FOUND"
      };
    }

    if (
      Number(data.quantitySold) >
      Number(pond.currentFishCount)
    ) {
      return {
        success: false,
        reason: "QUANTITY_EXCEEDS_STOCK"
      };
    }
  }

  const totalWeight =
    calculateTotalWeight(
      data.quantitySold,
      data.averageWeight
    );

  const totalAmount =
    calculateTotalAmount(
      data.quantitySold,
      data.averageWeight,
      data.pricePerKilogram
    );

  const amountPaid =
    Number(data.amountPaid) || 0;

  if (amountPaid > totalAmount) {
    return {
      success: false,
      reason: "PAYMENT_EXCEEDS_TOTAL"
    };
  }

  const paymentStatus =
    normalizePaymentStatus({
      paymentStatus:
        data.paymentStatus,
      amountPaid,
      totalAmount
    });

  const invoiceNumber =
    await generateInvoiceNumber();

  const sale =
    await Sale.create({
      customerName:
        data.customerName,

      phoneNumber:
        data.phoneNumber || "",

      pond:
        data.pond || null,

      quantitySold:
        data.quantitySold,

      averageWeight:
        data.averageWeight,

      totalWeight,

      pricePerKilogram:
        data.pricePerKilogram,

      totalAmount,

      amountPaid,

      paymentStatus,

      invoiceNumber,

      saleDate:
        data.saleDate || new Date(),

      notes:
        data.notes || ""
    });

  /*
   * Cancelled sales do not consume fish stock.
   */
  if (
    pond &&
    paymentStatus !== "cancelled"
  ) {
    pond.currentFishCount = Math.max(
      Number(pond.currentFishCount) -
        Number(data.quantitySold),
      0
    );

    await pond.save();
  }

  await ActivityLog.create({
    action: "create",
    entityType: "Sale",
    entityId: sale._id,
    description:
      `Sale ${sale.invoiceNumber} was recorded.`,
    metadata: {
      invoiceNumber:
        sale.invoiceNumber,
      customerName:
        sale.customerName,
      quantitySold:
        sale.quantitySold,
      totalAmount:
        sale.totalAmount,
      paymentStatus:
        sale.paymentStatus,
      pondId:
        sale.pond || null
    },
    ipAddress:
      ipAddress || "",
    userAgent:
      userAgent || ""
  });

  return {
    success: true,
    sale
  };
};

const listSales = async ({
  pond,
  paymentStatus,
  from,
  to,
  search,
  page = 1,
  limit = 30
}) => {
  const currentPage = Math.max(
    Number(page) || 1,
    1
  );

  const pageSize = Math.min(
    Math.max(Number(limit) || 30, 1),
    100
  );

  const filter = {};

  if (pond) {
    filter.pond = pond;
  }

  if (paymentStatus) {
    filter.paymentStatus =
      paymentStatus;
  }

  if (from || to) {
    filter.saleDate = {};

    if (from) {
      filter.saleDate.$gte =
        startOfDay(from);
    }

    if (to) {
      filter.saleDate.$lte =
        endOfDay(to);
    }
  }

  if (search) {
    filter.$or = [
      {
        customerName: {
          $regex: search,
          $options: "i"
        }
      },
      {
        phoneNumber: {
          $regex: search,
          $options: "i"
        }
      },
      {
        invoiceNumber: {
          $regex: search,
          $options: "i"
        }
      }
    ];
  }

  const [sales, total] =
    await Promise.all([
      Sale.find(filter)
        .populate(
          "pond",
          "pondName pondNumber currentFishCount"
        )
        .sort({
          saleDate: -1,
          createdAt: -1
        })
        .skip(
          (currentPage - 1) *
            pageSize
        )
        .limit(pageSize)
        .lean(),

      Sale.countDocuments(filter)
    ]);

  return {
    sales,
    pagination: {
      page: currentPage,
      limit: pageSize,
      total,
      pages: Math.ceil(
        total / pageSize
      )
    }
  };
};

const getSaleById = async (id) => {
  if (!mongoose.isValidObjectId(id)) {
    return null;
  }

  return Sale.findById(id)
    .populate(
      "pond",
      "pondName pondNumber currentFishCount"
    )
    .lean();
};

const updateSale = async ({
  id,
  data,
  ipAddress,
  userAgent
}) => {
  if (!mongoose.isValidObjectId(id)) {
    return {
      success: false,
      reason: "NOT_FOUND"
    };
  }

  const sale =
    await Sale.findById(id);

  if (!sale) {
    return {
      success: false,
      reason: "NOT_FOUND"
    };
  }

  const originalPondId =
    sale.pond
      ? String(sale.pond)
      : null;

  const originalQuantity =
    Number(sale.quantitySold);

  const originalStatus =
    sale.paymentStatus;

  const nextPondId =
    data.pond !== undefined
      ? data.pond
      : originalPondId;

  const nextQuantity =
    data.quantitySold !== undefined
      ? Number(data.quantitySold)
      : originalQuantity;

  const nextWeight =
    data.averageWeight !== undefined
      ? Number(data.averageWeight)
      : Number(sale.averageWeight);

  const nextPrice =
    data.pricePerKilogram !== undefined
      ? Number(data.pricePerKilogram)
      : Number(sale.pricePerKilogram);

  const nextTotalAmount =
    calculateTotalAmount(
      nextQuantity,
      nextWeight,
      nextPrice
    );

  const nextAmountPaid =
    data.amountPaid !== undefined
      ? Number(data.amountPaid)
      : Number(sale.amountPaid || 0);

  if (
    nextAmountPaid >
    nextTotalAmount
  ) {
    return {
      success: false,
      reason: "PAYMENT_EXCEEDS_TOTAL"
    };
  }

  const nextStatus =
    normalizePaymentStatus({
      paymentStatus:
        data.paymentStatus !== undefined
          ? data.paymentStatus
          : originalStatus,
      amountPaid:
        nextAmountPaid,
      totalAmount:
        nextTotalAmount
    });

  const oldActive =
    originalStatus !== "cancelled";

  const newActive =
    nextStatus !== "cancelled";

  /*
   * First restore stock consumed by the
   * original active sale.
   */
  if (
    originalPondId &&
    oldActive &&
    originalQuantity > 0
  ) {
    const originalPond =
      await Pond.findById(
        originalPondId
      );

    if (originalPond) {
      originalPond.currentFishCount +=
        originalQuantity;

      await originalPond.save();
    }
  }

  /*
   * Validate the replacement stock
   * before committing the new sale state.
   */
  let nextPond = null;

  if (nextPondId) {
    nextPond =
      await Pond.findById(
        nextPondId
      );

    if (!nextPond) {
      /*
       * Restore the original sale stock
       * because the update cannot proceed.
       */
      if (
        originalPondId &&
        oldActive &&
        originalQuantity > 0
      ) {
        const rollbackPond =
          await Pond.findById(
            originalPondId
          );

        if (rollbackPond) {
          rollbackPond.currentFishCount =
            Math.max(
              rollbackPond.currentFishCount -
                originalQuantity,
              0
            );

          await rollbackPond.save();
        }
      }

      return {
        success: false,
        reason: "POND_NOT_FOUND"
      };
    }

    if (
      newActive &&
      nextQuantity >
        Number(
          nextPond.currentFishCount
        )
    ) {
      /*
       * Restore the original stock
       * before returning the validation error.
       */
      if (
        originalPondId &&
        oldActive &&
        originalQuantity > 0
      ) {
        const rollbackPond =
          await Pond.findById(
            originalPondId
          );

        if (rollbackPond) {
          rollbackPond.currentFishCount =
            Math.max(
              rollbackPond.currentFishCount -
                originalQuantity,
              0
            );

          await rollbackPond.save();
        }
      }

      return {
        success: false,
        reason: "QUANTITY_EXCEEDS_STOCK"
      };
    }
  }

  if (
    data.customerName !== undefined
  ) {
    sale.customerName =
      data.customerName;
  }

  if (
    data.phoneNumber !== undefined
  ) {
    sale.phoneNumber =
      data.phoneNumber;
  }

  sale.pond =
    nextPondId || null;

  sale.quantitySold =
    nextQuantity;

  sale.averageWeight =
    nextWeight;

  sale.totalWeight =
    calculateTotalWeight(
      nextQuantity,
      nextWeight
    );

  sale.pricePerKilogram =
    nextPrice;

  sale.totalAmount =
    nextTotalAmount;

  sale.amountPaid =
    nextAmountPaid;

  sale.paymentStatus =
    nextStatus;

  if (data.saleDate !== undefined) {
    sale.saleDate =
      data.saleDate;
  }

  if (data.notes !== undefined) {
    sale.notes =
      data.notes;
  }

  await sale.save();

  /*
   * Consume stock for the new active sale.
   */
  if (
    nextPond &&
    newActive &&
    nextQuantity > 0
  ) {
    nextPond.currentFishCount =
      Math.max(
        Number(
          nextPond.currentFishCount
        ) - nextQuantity,
        0
      );

    await nextPond.save();
  }

  await ActivityLog.create({
    action: "update",
    entityType: "Sale",
    entityId: sale._id,
    description:
      `Sale ${sale.invoiceNumber} was updated.`,
    metadata: {
      invoiceNumber:
        sale.invoiceNumber,
      quantitySold:
        sale.quantitySold,
      totalAmount:
        sale.totalAmount,
      paymentStatus:
        sale.paymentStatus
    },
    ipAddress:
      ipAddress || "",
    userAgent:
      userAgent || ""
  });

  return {
    success: true,
    sale:
      await Sale.findById(sale._id)
        .populate(
          "pond",
          "pondName pondNumber currentFishCount"
        )
        .lean()
  };
};

const getSalesSummary = async ({
  from,
  to,
  pond
}) => {
  const filter = {
    paymentStatus: {
      $ne: "cancelled"
    }
  };

  if (pond) {
    filter.pond = pond;
  }

  if (from || to) {
    filter.saleDate = {};

    if (from) {
      filter.saleDate.$gte =
        startOfDay(from);
    }

    if (to) {
      filter.saleDate.$lte =
        endOfDay(to);
    }
  }

  const [
    summary,
    byDay,
    byPaymentStatus
  ] = await Promise.all([
    Sale.aggregate([
      {
        $match: filter
      },
      {
        $group: {
          _id: null,
          totalSales: {
            $sum: 1
          },
          totalFishSold: {
            $sum: "$quantitySold"
          },
          totalWeightKg: {
            $sum: "$totalWeight"
          },
          totalRevenue: {
            $sum: "$totalAmount"
          },
          totalCollected: {
            $sum: "$amountPaid"
          }
        }
      }
    ]),

    Sale.aggregate([
      {
        $match: filter
      },
      {
        $group: {
          _id: {
            $dateToString: {
              format: "%Y-%m-%d",
              date: "$saleDate"
            }
          },
          revenue: {
            $sum: "$totalAmount"
          },
          fishSold: {
            $sum: "$quantitySold"
          }
        }
      },
      {
        $sort: {
          _id: 1
        }
      },
      {
        $project: {
          _id: 0,
          date: "$_id",
          revenue: 1,
          fishSold: 1
        }
      }
    ]),

    Sale.aggregate([
      {
        $match: {
          ...filter,
          paymentStatus: {
            $exists: true
          }
        }
      },
      {
        $group: {
          _id: "$paymentStatus",
          count: {
            $sum: 1
          },
          amount: {
            $sum: "$totalAmount"
          }
        }
      },
      {
        $project: {
          _id: 0,
          status: "$_id",
          count: 1,
          amount: 1
        }
      }
    ])
  ]);

  return {
    totals: {
      totalSales:
        summary[0]?.totalSales || 0,

      totalFishSold:
        summary[0]?.totalFishSold || 0,

      totalWeightKg:
        Number(
          (
            summary[0]?.totalWeightKg ||
            0
          ).toFixed(3)
        ),

      totalRevenue:
        Number(
          (
            summary[0]?.totalRevenue ||
            0
          ).toFixed(2)
        ),

      totalCollected:
        Number(
          (
            summary[0]?.totalCollected ||
            0
          ).toFixed(2)
        )
    },

    byDay,

    byPaymentStatus
  };
};

module.exports = {
  createSale,
  listSales,
  getSaleById,
  updateSale,
  getSalesSummary,
  calculateTotalAmount,
  calculateTotalWeight
};