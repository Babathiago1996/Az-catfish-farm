const mongoose = require("mongoose");

const Mortality = require("../models/Mortality");
const Pond = require("../models/Pond");
const ActivityLog = require("../models/ActivityLog");

const startOfDay = (value) => {
  const date = new Date(value);
  date.setHours(0, 0, 0, 0);
  return date;
};

const endOfDay = (value) => {
  const date = new Date(value);
  date.setHours(23, 59, 59, 999);
  return date;
};

const getMortalityTotalForPond = async (
  pondId
) => {
  const result =
    await Mortality.aggregate([
      {
        $match: {
          pond: new mongoose.Types.ObjectId(
            pondId
          )
        }
      },
      {
        $group: {
          _id: null,
          total: {
            $sum: "$quantity"
          }
        }
      }
    ]);

  return result[0]?.total || 0;
};

const recalculatePondFishCount =
  async (pondId) => {
    const pond =
      await Pond.findById(pondId);

    if (!pond) {
      return null;
    }

    /*
     * Stocking records establish the total
     * quantity stocked into the pond.
     *
     * Mortality records are then deducted
     * from that total.
     */
    const Stocking =
      require("../models/Stocking");

    const stockingResult =
      await Stocking.aggregate([
        {
          $match: {
            pond: new mongoose.Types.ObjectId(
              pondId
            )
          }
        },
        {
          $group: {
            _id: null,
            totalStocked: {
              $sum: "$fingerlingQuantity"
            }
          }
        }
      ]);

    const totalStocked =
      stockingResult[0]?.totalStocked || 0;

    const totalMortality =
      await getMortalityTotalForPond(
        pondId
      );

    const currentFishCount = Math.max(
      totalStocked - totalMortality,
      0
    );

    pond.currentFishCount =
      currentFishCount;

    await pond.save();

    return pond;
  };

const createMortality = async ({
  data,
  ipAddress,
  userAgent
}) => {
  if (
    !mongoose.isValidObjectId(data.pond)
  ) {
    return {
      success: false,
      reason: "POND_NOT_FOUND"
    };
  }

  const pond =
    await Pond.findById(data.pond);

  if (!pond) {
    return {
      success: false,
      reason: "POND_NOT_FOUND"
    };
  }

  /*
   * Prevent the recorded mortality from
   * exceeding the fish currently available.
   */
  if (
    Number(data.quantity) >
    Number(pond.currentFishCount)
  ) {
    return {
      success: false,
      reason: "QUANTITY_EXCEEDS_STOCK"
    };
  }

  const record =
    await Mortality.create({
      date: data.date,
      pond: data.pond,
      quantity: data.quantity,
      estimatedCause:
        data.estimatedCause || "",
      notes: data.notes || "",
      imageUrl:
        data.imageUrl || "",
      imagePublicId:
        data.imagePublicId || ""
    });

  const updatedPond =
    await recalculatePondFishCount(
      data.pond
    );

  await ActivityLog.create({
    action: "create",
    entityType: "Mortality",
    entityId: record._id,
    description:
      `${record.quantity} fish mortality was recorded.`,
    metadata: {
      pondId: record.pond,
      quantity: record.quantity,
      estimatedCause:
        record.estimatedCause,
      remainingFish:
        updatedPond?.currentFishCount || 0
    },
    ipAddress: ipAddress || "",
    userAgent: userAgent || ""
  });

  return {
    success: true,
    record,
    pond: updatedPond
  };
};

const listMortality = async ({
  pond,
  from,
  to,
  page = 1,
  limit = 30
}) => {
  const currentPage = Math.max(
    Number(page) || 1,
    1
  );

  const pageSize = Math.min(
    Math.max(Number(limit) || 30, 1),
    100
  );

  const filter = {};

  if (pond) {
    filter.pond = pond;
  }

  if (from || to) {
    filter.date = {};

    if (from) {
      filter.date.$gte =
        startOfDay(from);
    }

    if (to) {
      filter.date.$lte =
        endOfDay(to);
    }
  }

  const [records, total] =
    await Promise.all([
      Mortality.find(filter)
        .populate(
          "pond",
          "pondName pondNumber currentFishCount"
        )
        .sort({
          date: -1,
          createdAt: -1
        })
        .skip((currentPage - 1) * pageSize)
        .limit(pageSize)
        .lean(),

      Mortality.countDocuments(filter)
    ]);

  return {
    records,
    pagination: {
      page: currentPage,
      limit: pageSize,
      total,
      pages: Math.ceil(
        total / pageSize
      )
    }
  };
};

const getMortalityById = async (id) => {
  if (!mongoose.isValidObjectId(id)) {
    return null;
  }

  return Mortality.findById(id)
    .populate(
      "pond",
      "pondName pondNumber currentFishCount"
    )
    .lean();
};

const updateMortality = async ({
  id,
  data,
  ipAddress,
  userAgent
}) => {
  if (!mongoose.isValidObjectId(id)) {
    return {
      success: false,
      reason: "NOT_FOUND"
    };
  }

  const record =
    await Mortality.findById(id);

  if (!record) {
    return {
      success: false,
      reason: "NOT_FOUND"
    };
  }

  const oldPondId =
    String(record.pond);

  const newPondId =
    data.pond
      ? String(data.pond)
      : oldPondId;

  const targetPond =
    await Pond.findById(newPondId);

  if (!targetPond) {
    return {
      success: false,
      reason: "POND_NOT_FOUND"
    };
  }

  /*
   * Temporarily remove the old record's
   * contribution from the target pond when
   * checking a quantity update on the same pond.
   */
  if (
    newPondId === oldPondId &&
    data.quantity !== undefined
  ) {
    const otherMortality =
      await Mortality.aggregate([
        {
          $match: {
            pond:
              new mongoose.Types.ObjectId(
                newPondId
              ),
            _id: {
              $ne: record._id
            }
          }
        },
        {
          $group: {
            _id: null,
            total: {
              $sum: "$quantity"
            }
          }
        }
      ]);

    const Stocking =
      require("../models/Stocking");

    const stocking =
      await Stocking.aggregate([
        {
          $match: {
            pond:
              new mongoose.Types.ObjectId(
                newPondId
              )
          }
        },
        {
          $group: {
            _id: null,
            total: {
              $sum: "$fingerlingQuantity"
            }
          }
        }
      ]);

    const totalStocked =
      stocking[0]?.total || 0;

    const otherMortalityTotal =
      otherMortality[0]?.total || 0;

    const available =
      Math.max(
        totalStocked -
          otherMortalityTotal,
        0
      );

    if (
      Number(data.quantity) >
      available
    ) {
      return {
        success: false,
        reason: "QUANTITY_EXCEEDS_STOCK"
      };
    }
  }

  if (data.date !== undefined) {
    record.date = data.date;
  }

  if (data.pond !== undefined) {
    record.pond = data.pond;
  }

  if (data.quantity !== undefined) {
    record.quantity = data.quantity;
  }

  if (
    data.estimatedCause !==
    undefined
  ) {
    record.estimatedCause =
      data.estimatedCause;
  }

  if (data.notes !== undefined) {
    record.notes = data.notes;
  }

  if (data.imageUrl !== undefined) {
    record.imageUrl = data.imageUrl;
  }

  if (
    data.imagePublicId !== undefined
  ) {
    record.imagePublicId =
      data.imagePublicId;
  }

  await record.save();

  /*
   * Recalculate both ponds if the record
   * was moved from one pond to another.
   */
  const pondsToUpdate =
    oldPondId === newPondId
      ? [newPondId]
      : [oldPondId, newPondId];

  for (const pondId of pondsToUpdate) {
    await recalculatePondFishCount(
      pondId
    );
  }

  await ActivityLog.create({
    action: "update",
    entityType: "Mortality",
    entityId: record._id,
    description:
      "Mortality record was updated.",
    metadata: {
      pondId: record.pond,
      quantity: record.quantity,
      estimatedCause:
        record.estimatedCause
    },
    ipAddress: ipAddress || "",
    userAgent: userAgent || ""
  });

  return {
    success: true,
    record:
      await Mortality.findById(record._id)
        .populate(
          "pond",
          "pondName pondNumber currentFishCount"
        )
        .lean()
  };
};

const getMortalitySummary = async ({
  pond,
  from,
  to
}) => {
  const filter = {};

  if (pond) {
    filter.pond = pond;
  }

  if (from || to) {
    filter.date = {};

    if (from) {
      filter.date.$gte =
        startOfDay(from);
    }

    if (to) {
      filter.date.$lte =
        endOfDay(to);
    }
  }

  const [
    aggregate,
    byPond,
    byCause
  ] = await Promise.all([
    Mortality.aggregate([
      {
        $match: filter
      },
      {
        $group: {
          _id: null,
          totalMortality: {
            $sum: "$quantity"
          },
          records: {
            $sum: 1
          }
        }
      }
    ]),

    Mortality.aggregate([
      {
        $match: filter
      },
      {
        $group: {
          _id: "$pond",
          quantity: {
            $sum: "$quantity"
          }
        }
      },
      {
        $lookup: {
          from: "ponds",
          localField: "_id",
          foreignField: "_id",
          as: "pond"
        }
      },
      {
        $unwind: {
          path: "$pond",
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $project: {
          _id: 0,
          pondId: "$_id",
          pondName:
            "$pond.pondName",
          pondNumber:
            "$pond.pondNumber",
          quantity: 1
        }
      },
      {
        $sort: {
          quantity: -1
        }
      }
    ]),

    Mortality.aggregate([
      {
        $match: filter
      },
      {
        $group: {
          _id: {
            $cond: [
              {
                $eq: [
                  {
                    $trim: {
                      input:
                        "$estimatedCause"
                    }
                  },
                  ""
                ]
              },
              "Unknown",
              "$estimatedCause"
            ]
          },
          quantity: {
            $sum: "$quantity"
          }
        }
      },
      {
        $project: {
          _id: 0,
          cause: "$_id",
          quantity: 1
        }
      },
      {
        $sort: {
          quantity: -1
        }
      }
    ])
  ]);

  return {
    totalMortality:
      aggregate[0]?.totalMortality || 0,

    records:
      aggregate[0]?.records || 0,

    byPond,

    byCause
  };
};

module.exports = {
  createMortality,
  listMortality,
  getMortalityById,
  updateMortality,
  getMortalitySummary,
  recalculatePondFishCount,
  getMortalityTotalForPond
};