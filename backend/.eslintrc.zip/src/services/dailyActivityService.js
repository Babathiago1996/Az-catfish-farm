const mongoose = require("mongoose");

const DailyActivity = require("../models/DailyActivity");
const Pond = require("../models/Pond");
const ActivityLog = require("../models/ActivityLog");

const allowedFields = [
  "date",
  "activityType",
  "title",
  "period",
  "pond",
  "notes",
  "status"
];

const pickFields = (data) =>
  allowedFields.reduce((result, field) => {
    if (data[field] !== undefined) {
      result[field] = data[field];
    }

    return result;
  }, {});

const dateStart = (value) => {
  const date = new Date(value);
  date.setHours(0, 0, 0, 0);
  return date;
};

const dateEnd = (value) => {
  const date = new Date(value);
  date.setHours(23, 59, 59, 999);
  return date;
};

const validatePond = async (pondId) => {
  if (!pondId) {
    return true;
  }

  if (!mongoose.isValidObjectId(pondId)) {
    return false;
  }

  const pond = await Pond.exists({
    _id: pondId
  });

  return Boolean(pond);
};

const createActivity = async ({
  data,
  ipAddress,
  userAgent
}) => {
  if (
    data.pond &&
    !(await validatePond(data.pond))
  ) {
    return {
      success: false,
      reason: "POND_NOT_FOUND"
    };
  }

  const activityData = pickFields(data);

  if (!activityData.date) {
    activityData.date = new Date();
  }

  if (!activityData.period) {
    activityData.period = "other";
  }

  if (!activityData.status) {
    activityData.status = "completed";
  }

  const activity =
    await DailyActivity.create(activityData);

  await ActivityLog.create({
    action: "create",
    entityType: "DailyActivity",
    entityId: activity._id,
    description:
      `Farm activity "${activity.title}" was recorded.`,
    metadata: {
      activityType: activity.activityType,
      pond: activity.pond || null
    },
    ipAddress: ipAddress || "",
    userAgent: userAgent || ""
  });

  return {
    success: true,
    activity
  };
};

const listActivities = async ({
  date,
  from,
  to,
  activityType,
  status,
  pond,
  page = 1,
  limit = 30
}) => {
  const currentPage = Math.max(
    Number(page) || 1,
    1
  );

  const pageSize = Math.min(
    Math.max(Number(limit) || 30, 1),
    100
  );

  const filter = {};

  if (date) {
    filter.date = {
      $gte: dateStart(date),
      $lte: dateEnd(date)
    };
  } else if (from || to) {
    filter.date = {};

    if (from) {
      filter.date.$gte = dateStart(from);
    }

    if (to) {
      filter.date.$lte = dateEnd(to);
    }
  }

  if (activityType) {
    filter.activityType = activityType;
  }

  if (status) {
    filter.status = status;
  }

  if (pond) {
    filter.pond = pond;
  }

  const [activities, total] =
    await Promise.all([
      DailyActivity.find(filter)
        .populate(
          "pond",
          "pondName pondNumber status"
        )
        .sort({
          date: -1,
          createdAt: -1
        })
        .skip((currentPage - 1) * pageSize)
        .limit(pageSize)
        .lean(),

      DailyActivity.countDocuments(filter)
    ]);

  return {
    activities,
    pagination: {
      page: currentPage,
      limit: pageSize,
      total,
      pages: Math.ceil(total / pageSize)
    }
  };
};

const getActivityById = async (id) => {
  if (!mongoose.isValidObjectId(id)) {
    return null;
  }

  return DailyActivity.findById(id)
    .populate(
      "pond",
      "pondName pondNumber status"
    )
    .lean();
};

const updateActivity = async ({
  activityId,
  data,
  ipAddress,
  userAgent
}) => {
  if (!mongoose.isValidObjectId(activityId)) {
    return {
      success: false,
      reason: "ACTIVITY_NOT_FOUND"
    };
  }

  const activity =
    await DailyActivity.findById(activityId);

  if (!activity) {
    return {
      success: false,
      reason: "ACTIVITY_NOT_FOUND"
    };
  }

  if (
    data.pond &&
    !(await validatePond(data.pond))
  ) {
    return {
      success: false,
      reason: "POND_NOT_FOUND"
    };
  }

  Object.assign(
    activity,
    pickFields(data)
  );

  await activity.save();

  await ActivityLog.create({
    action: "update",
    entityType: "DailyActivity",
    entityId: activity._id,
    description:
      `Farm activity "${activity.title}" was updated.`,
    metadata: pickFields(data),
    ipAddress: ipAddress || "",
    userAgent: userAgent || ""
  });

  return {
    success: true,
    activity
  };
};

const deleteActivity = async ({
  activityId,
  ipAddress,
  userAgent
}) => {
  if (!mongoose.isValidObjectId(activityId)) {
    return {
      success: false,
      reason: "ACTIVITY_NOT_FOUND"
    };
  }

  const activity =
    await DailyActivity.findById(activityId);

  if (!activity) {
    return {
      success: false,
      reason: "ACTIVITY_NOT_FOUND"
    };
  }

  await DailyActivity.deleteOne({
    _id: activity._id
  });

  await ActivityLog.create({
    action: "delete",
    entityType: "DailyActivity",
    entityId: activity._id,
    description:
      `Farm activity "${activity.title}" was deleted.`,
    metadata: {
      activityType: activity.activityType
    },
    ipAddress: ipAddress || "",
    userAgent: userAgent || ""
  });

  return {
    success: true
  };
};

module.exports = {
  createActivity,
  listActivities,
  getActivityById,
  updateActivity,
  deleteActivity
};