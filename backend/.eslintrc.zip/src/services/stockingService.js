const mongoose = require("mongoose");

const Stocking = require("../models/Stocking");
const Pond = require("../models/Pond");
const ActivityLog = require("../models/ActivityLog");

const createStocking = async ({
  data,
  ipAddress,
  userAgent
}) => {
  if (!mongoose.isValidObjectId(data.pond)) {
    return {
      success: false,
      reason: "POND_NOT_FOUND"
    };
  }

  const pond = await Pond.findById(data.pond);

  if (!pond) {
    return {
      success: false,
      reason: "POND_NOT_FOUND"
    };
  }

  if (pond.status === "maintenance") {
    return {
      success: false,
      reason: "POND_MAINTENANCE"
    };
  }

  const session = await mongoose.startSession();

  try {
    let stocking;

    await session.withTransaction(async () => {
      stocking = await Stocking.create(
        [
          {
            stockingDate: data.stockingDate,
            pond: pond._id,
            fingerlingQuantity:
              data.fingerlingQuantity,
            fingerlingSize: data.fingerlingSize,
            supplier: data.supplier || "",
            cost: data.cost,
            expectedHarvestDate:
              data.expectedHarvestDate || null,
            initialWeight:
              data.initialWeight || 0,
            notes: data.notes || ""
          }
        ],
        { session }
      );

      pond.currentFishCount =
        Number(pond.currentFishCount || 0) +
        Number(data.fingerlingQuantity);

      pond.stockingDate = data.stockingDate;
      pond.status = "active";

      await pond.save({ session });
    });

    const createdStocking = stocking[0];

    await ActivityLog.create({
      action: "stocking",
      entityType: "Stocking",
      entityId: createdStocking._id,
      description:
        `Stocking of ${data.fingerlingQuantity} fingerlings was recorded for pond "${pond.pondName}".`,
      metadata: {
        pondId: pond._id,
        quantity: data.fingerlingQuantity,
        cost: data.cost
      },
      ipAddress: ipAddress || "",
      userAgent: userAgent || ""
    });

    return {
      success: true,
      stocking: createdStocking,
      pond
    };
  } finally {
    await session.endSession();
  }
};

const listStocking = async ({
  pond,
  from,
  to,
  page = 1,
  limit = 20
}) => {
  const currentPage = Math.max(
    Number(page) || 1,
    1
  );

  const pageSize = Math.min(
    Math.max(Number(limit) || 20, 1),
    100
  );

  const filter = {};

  if (pond) {
    filter.pond = pond;
  }

  if (from || to) {
    filter.stockingDate = {};

    if (from) {
      filter.stockingDate.$gte = new Date(from);
    }

    if (to) {
      const endDate = new Date(to);
      endDate.setHours(23, 59, 59, 999);

      filter.stockingDate.$lte = endDate;
    }
  }

  const [records, total] = await Promise.all([
    Stocking.find(filter)
      .populate(
        "pond",
        "pondName pondNumber status"
      )
      .sort({
        stockingDate: -1,
        createdAt: -1
      })
      .skip((currentPage - 1) * pageSize)
      .limit(pageSize)
      .lean(),

    Stocking.countDocuments(filter)
  ]);

  return {
    records,
    pagination: {
      page: currentPage,
      limit: pageSize,
      total,
      pages: Math.ceil(total / pageSize)
    }
  };
};

const getStockingById = async (id) => {
  if (!mongoose.isValidObjectId(id)) {
    return null;
  }

  return Stocking.findById(id)
    .populate(
      "pond",
      "pondName pondNumber status currentFishCount"
    )
    .lean();
};

module.exports = {
  createStocking,
  listStocking,
  getStockingById
};