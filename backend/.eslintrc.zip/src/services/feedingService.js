const mongoose = require("mongoose");

const FeedingRecord = require("../models/FeedingRecord");
const Pond = require("../models/Pond");
const Inventory = require("../models/Inventory");
const InventoryTransaction = require("../models/InventoryTransaction");
const ActivityLog = require("../models/ActivityLog");

const dateStart = (value) => {
  const date = new Date(value);
  date.setHours(0, 0, 0, 0);
  return date;
};

const dateEnd = (value) => {
  const date = new Date(value);
  date.setHours(23, 59, 59, 999);
  return date;
};

const findFeedInventory = async ({
  brand,
  size
}) => {
  const regexBrand = new RegExp(
    `^${String(brand).replace(
      /[.*+?^${}()|[\]\\]/g,
      "\\$&"
    )}$`,
    "i"
  );

  const regexSize = new RegExp(
    `^${String(size).replace(
      /[.*+?^${}()|[\]\\]/g,
      "\\$&"
    )}$`,
    "i"
  );

  return Inventory.findOne({
    category: "feed",
    $or: [
      {
        itemName: regexBrand,
        unit: regexSize
      },
      {
        itemName: regexBrand
      }
    ]
  });
};

const createFeeding = async ({
  data,
  ipAddress,
  userAgent
}) => {
  if (!mongoose.isValidObjectId(data.pond)) {
    return {
      success: false,
      reason: "POND_NOT_FOUND"
    };
  }

  const pond = await Pond.findById(data.pond);

  if (!pond) {
    return {
      success: false,
      reason: "POND_NOT_FOUND"
    };
  }

  if (
    pond.status === "inactive" ||
    pond.status === "maintenance"
  ) {
    return {
      success: false,
      reason: "POND_UNAVAILABLE"
    };
  }

  const quantity = Number(data.quantityUsed);

  const session = await mongoose.startSession();

  try {
    let feeding;
    let inventoryItem = null;

    await session.withTransaction(async () => {
      inventoryItem = await findFeedInventory({
        brand: data.feedBrand,
        size: data.feedSize
      });

      if (inventoryItem) {
        const available =
          Number(inventoryItem.quantity || 0);

        if (available < quantity) {
          const error = new Error(
            "INSUFFICIENT_FEED"
          );

          error.code = "INSUFFICIENT_FEED";
          error.available = available;

          throw error;
        }

        inventoryItem.quantity =
          available - quantity;

        await inventoryItem.save({
          session
        });
      }

      const records = await FeedingRecord.create(
        [
          {
            date: data.date || new Date(),
            pond: pond._id,
            feedBrand: data.feedBrand,
            feedType: data.feedType,
            feedSize: data.feedSize,
            quantityUsed: quantity,
            feedingTime:
              data.feedingTime || "",
            cost: Number(data.cost || 0),
            notes: data.notes || ""
          }
        ],
        {
          session
        }
      );

      feeding = records[0];

      if (inventoryItem) {
        await InventoryTransaction.create(
          [
            {
              inventory: inventoryItem._id,
              type: "out",
              quantity,
              reason: "feeding",
              referenceId: feeding._id,
              notes:
                `Feed consumed by ${pond.pondName}.`
            }
          ],
          {
            session
          }
        );
      }
    });

    await ActivityLog.create({
      action: "feeding",
      entityType: "FeedingRecord",
      entityId: feeding._id,
      description:
        `Recorded ${quantity} units of feed for pond "${pond.pondName}".`,
      metadata: {
        pondId: pond._id,
        quantityUsed: quantity,
        feedBrand: data.feedBrand,
        feedSize: data.feedSize,
        inventoryUpdated: Boolean(inventoryItem)
      },
      ipAddress: ipAddress || "",
      userAgent: userAgent || ""
    });

    const remainingFeed =
      inventoryItem?.quantity ?? null;

    return {
      success: true,
      feeding,
      remainingFeed,
      inventoryUpdated: Boolean(inventoryItem)
    };
  } catch (error) {
    if (error.code === "INSUFFICIENT_FEED") {
      return {
        success: false,
        reason: "INSUFFICIENT_FEED",
        available: error.available
      };
    }

    throw error;
  } finally {
    await session.endSession();
  }
};

const listFeedings = async ({
  pond,
  from,
  to,
  page = 1,
  limit = 30
}) => {
  const currentPage = Math.max(
    Number(page) || 1,
    1
  );

  const pageSize = Math.min(
    Math.max(Number(limit) || 30, 1),
    100
  );

  const filter = {};

  if (pond) {
    filter.pond = pond;
  }

  if (from || to) {
    filter.date = {};

    if (from) {
      filter.date.$gte = dateStart(from);
    }

    if (to) {
      filter.date.$lte = dateEnd(to);
    }
  }

  const [records, total] =
    await Promise.all([
      FeedingRecord.find(filter)
        .populate(
          "pond",
          "pondName pondNumber status"
        )
        .sort({
          date: -1,
          createdAt: -1
        })
        .skip((currentPage - 1) * pageSize)
        .limit(pageSize)
        .lean(),

      FeedingRecord.countDocuments(filter)
    ]);

  const consumption = await FeedingRecord.aggregate([
    {
      $match: filter
    },
    {
      $group: {
        _id: null,
        totalQuantity: {
          $sum: "$quantityUsed"
        },
        totalCost: {
          $sum: "$cost"
        }
      }
    }
  ]);

  return {
    records,
    summary: {
      totalQuantity:
        consumption[0]?.totalQuantity || 0,
      totalCost:
        consumption[0]?.totalCost || 0
    },
    pagination: {
      page: currentPage,
      limit: pageSize,
      total,
      pages: Math.ceil(total / pageSize)
    }
  };
};

const getFeedingById = async (id) => {
  if (!mongoose.isValidObjectId(id)) {
    return null;
  }

  return FeedingRecord.findById(id)
    .populate(
      "pond",
      "pondName pondNumber status"
    )
    .lean();
};

const getTodayConsumption = async () => {
  const start = dateStart(new Date());
  const end = dateEnd(new Date());

  const result = await FeedingRecord.aggregate([
    {
      $match: {
        date: {
          $gte: start,
          $lte: end
        }
      }
    },
    {
      $group: {
        _id: null,
        quantity: {
          $sum: "$quantityUsed"
        },
        cost: {
          $sum: "$cost"
        }
      }
    }
  ]);

  return {
    quantity: result[0]?.quantity || 0,
    cost: result[0]?.cost || 0
  };
};

module.exports = {
  createFeeding,
  listFeedings,
  getFeedingById,
  getTodayConsumption
};