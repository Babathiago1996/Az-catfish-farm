const mongoose = require("mongoose");

const Expense = require("../models/Expense");
const ActivityLog = require("../models/ActivityLog");

const startOfDay = (value) => {
  const date = new Date(value);

  date.setHours(
    0,
    0,
    0,
    0
  );

  return date;
};

const endOfDay = (value) => {
  const date = new Date(value);

  date.setHours(
    23,
    59,
    59,
    999
  );

  return date;
};

const buildDateFilter = (
  from,
  to
) => {
  if (!from && !to) {
    return undefined;
  }

  const filter = {};

  if (from) {
    filter.$gte =
      startOfDay(from);
  }

  if (to) {
    filter.$lte =
      endOfDay(to);
  }

  return filter;
};

const createExpense = async ({
  data,
  ipAddress,
  userAgent
}) => {
  const expense =
    await Expense.create({
      category:
        data.category,

      description:
        data.description,

      amount:
        data.amount,

      expenseDate:
        data.expenseDate ||
        new Date(),

      vendor:
        data.vendor || "",

      reference:
        data.reference || "",

      notes:
        data.notes || "",

      receiptImage:
        data.receiptImage || ""
    });

  await ActivityLog.create({
    action: "create",
    entityType: "Expense",
    entityId: expense._id,
    description:
      `Expense of ₦${Number(
        expense.amount
      ).toLocaleString(
        "en-NG",
        {
          minimumFractionDigits: 2
        }
      )} was recorded.`,
    metadata: {
      category:
        expense.category,

      amount:
        expense.amount,

      description:
        expense.description
    },
    ipAddress:
      ipAddress || "",
    userAgent:
      userAgent || ""
  });

  return expense;
};

const listExpenses = async ({
  category,
  from,
  to,
  search,
  page = 1,
  limit = 30
}) => {
  const currentPage =
    Math.max(
      Number(page) || 1,
      1
    );

  const pageSize =
    Math.min(
      Math.max(
        Number(limit) || 30,
        1
      ),
      100
    );

  const filter = {};

  if (category) {
    filter.category =
      category;
  }

  const dateFilter =
    buildDateFilter(
      from,
      to
    );

  if (dateFilter) {
    filter.expenseDate =
      dateFilter;
  }

  if (search) {
    filter.$or = [
      {
        description: {
          $regex: search,
          $options: "i"
        }
      },
      {
        vendor: {
          $regex: search,
          $options: "i"
        }
      },
      {
        reference: {
          $regex: search,
          $options: "i"
        }
      }
    ];
  }

  const [
    expenses,
    total,
    aggregate
  ] = await Promise.all([
    Expense.find(filter)
      .sort({
        expenseDate: -1,
        createdAt: -1
      })
      .skip(
        (currentPage - 1) *
          pageSize
      )
      .limit(pageSize)
      .lean(),

    Expense.countDocuments(filter),

    Expense.aggregate([
      {
        $match: filter
      },
      {
        $group: {
          _id: null,
          total: {
            $sum: "$amount"
          }
        }
      }
    ])
  ]);

  return {
    expenses,
    totalAmount:
      Number(
        (
          aggregate[0]?.total ||
          0
        ).toFixed(2)
      ),
    pagination: {
      page: currentPage,
      limit: pageSize,
      total,
      pages: Math.ceil(
        total / pageSize
      )
    }
  };
};

const getExpenseById = async (
  id
) => {
  if (
    !mongoose.isValidObjectId(id)
  ) {
    return null;
  }

  return Expense.findById(id)
    .lean();
};

const updateExpense = async ({
  id,
  data,
  ipAddress,
  userAgent
}) => {
  if (
    !mongoose.isValidObjectId(id)
  ) {
    return {
      success: false,
      reason: "NOT_FOUND"
    };
  }

  const expense =
    await Expense.findById(id);

  if (!expense) {
    return {
      success: false,
      reason: "NOT_FOUND"
    };
  }

  const allowedFields = [
    "category",
    "description",
    "amount",
    "expenseDate",
    "vendor",
    "reference",
    "notes",
    "receiptImage"
  ];

  allowedFields.forEach(
    (field) => {
      if (
        data[field] !== undefined
      ) {
        expense[field] =
          data[field];
      }
    }
  );

  await expense.save();

  await ActivityLog.create({
    action: "update",
    entityType: "Expense",
    entityId: expense._id,
    description:
      `Expense ${expense._id} was updated.`,
    metadata: {
      category:
        expense.category,

      amount:
        expense.amount
    },
    ipAddress:
      ipAddress || "",
    userAgent:
      userAgent || ""
  });

  return {
    success: true,
    expense:
      expense.toObject()
  };
};

const deleteExpense = async ({
  id,
  ipAddress,
  userAgent
}) => {
  if (
    !mongoose.isValidObjectId(id)
  ) {
    return {
      success: false,
      reason: "NOT_FOUND"
    };
  }

  const expense =
    await Expense.findById(id);

  if (!expense) {
    return {
      success: false,
      reason: "NOT_FOUND"
    };
  }

  await Expense.deleteOne({
    _id: expense._id
  });

  await ActivityLog.create({
    action: "delete",
    entityType: "Expense",
    entityId: expense._id,
    description:
      `Expense ${expense._id} was deleted.`,
    metadata: {
      category:
        expense.category,

      amount:
        expense.amount,

      description:
        expense.description
    },
    ipAddress:
      ipAddress || "",
    userAgent:
      userAgent || ""
  });

  return {
    success: true
  };
};

const getExpenseSummary = async ({
  from,
  to,
  category
}) => {
  const match = {};

  const dateFilter =
    buildDateFilter(
      from,
      to
    );

  if (dateFilter) {
    match.expenseDate =
      dateFilter;
  }

  if (category) {
    match.category =
      category;
  }

  const [
    totals,
    byCategory,
    byMonth,
    byDay
  ] = await Promise.all([
    Expense.aggregate([
      {
        $match: match
      },
      {
        $group: {
          _id: null,
          totalExpenses: {
            $sum: "$amount"
          },
          expenseCount: {
            $sum: 1
          }
        }
      }
    ]),

    Expense.aggregate([
      {
        $match: match
      },
      {
        $group: {
          _id: "$category",
          amount: {
            $sum: "$amount"
          },
          count: {
            $sum: 1
          }
        }
      },
      {
        $sort: {
          amount: -1
        }
      },
      {
        $project: {
          _id: 0,
          category: "$_id",
          amount: 1,
          count: 1
        }
      }
    ]),

    Expense.aggregate([
      {
        $match: match
      },
      {
        $group: {
          _id: {
            year: {
              $year:
                "$expenseDate"
            },
            month: {
              $month:
                "$expenseDate"
            }
          },
          amount: {
            $sum: "$amount"
          }
        }
      },
      {
        $sort: {
          "_id.year": 1,
          "_id.month": 1
        }
      },
      {
        $project: {
          _id: 0,
          year: "$_id.year",
          month: "$_id.month",
          amount: 1
        }
      }
    ]),

    Expense.aggregate([
      {
        $match: match
      },
      {
        $group: {
          _id: {
            $dateToString: {
              format:
                "%Y-%m-%d",
              date:
                "$expenseDate"
            }
          },
          amount: {
            $sum: "$amount"
          }
        }
      },
      {
        $sort: {
          _id: 1
        }
      },
      {
        $project: {
          _id: 0,
          date: "$_id",
          amount: 1
        }
      }
    ])
  ]);

  return {
    totalExpenses:
      Number(
        (
          totals[0]
            ?.totalExpenses ||
          0
        ).toFixed(2)
      ),

    expenseCount:
      totals[0]
        ?.expenseCount || 0,

    byCategory,

    byMonth,

    byDay
  };
};

const getMonthlyExpenses = async (
  year,
  month
) => {
  const numericYear =
    Number(year);

  const numericMonth =
    Number(month);

  if (
    !Number.isInteger(
      numericYear
    ) ||
    !Number.isInteger(
      numericMonth
    ) ||
    numericMonth < 1 ||
    numericMonth > 12
  ) {
    throw new Error(
      "Invalid year or month."
    );
  }

  const start =
    new Date(
      numericYear,
      numericMonth - 1,
      1
    );

  const end =
    new Date(
      numericYear,
      numericMonth,
      1
    );

  return getExpenseSummary({
    from: start,
    to: new Date(
      end.getTime() - 1
    )
  });
};

module.exports = {
  createExpense,
  listExpenses,
  getExpenseById,
  updateExpense,
  deleteExpense,
  getExpenseSummary,
  getMonthlyExpenses
};