const mongoose = require("mongoose");

const WaterManagement = require("../models/WaterManagement");
const Pond = require("../models/Pond");
const ActivityLog = require("../models/ActivityLog");

const dateStart = (value) => {
  const date = new Date(value);
  date.setHours(0, 0, 0, 0);
  return date;
};

const dateEnd = (value) => {
  const date = new Date(value);
  date.setHours(23, 59, 59, 999);
  return date;
};

const getWaterChangeStatus = (nextWaterChange) => {
  if (!nextWaterChange) {
    return "unknown";
  }

  const today = dateStart(new Date());
  const nextDate = dateStart(nextWaterChange);

  if (nextDate < today) {
    return "overdue";
  }

  if (nextDate.getTime() === today.getTime()) {
    return "due";
  }

  return "upcoming";
};

const validatePond = async (pondId) => {
  if (!pondId || !mongoose.isValidObjectId(pondId)) {
    return false;
  }

  return Boolean(
    await Pond.exists({
      _id: pondId
    })
  );
};

const populateRecord = (query) =>
  query.populate(
    "pond",
    "pondName pondNumber pondType pondSize status currentFishCount"
  );

const createWaterManagement = async ({
  data,
  ipAddress,
  userAgent
}) => {
  if (!(await validatePond(data.pond))) {
    return {
      success: false,
      reason: "POND_NOT_FOUND"
    };
  }

  const recordData = {
    pond: data.pond,
    lastWaterChange:
      data.lastWaterChange || null,
    nextWaterChange:
      data.nextWaterChange || null,
    waterQualityNotes:
      data.waterQualityNotes || "",
    pumpStatus:
      data.pumpStatus || "operational",
    electricityStatus:
      data.electricityStatus || "available",
    notes: data.notes || ""
  };

  const existing =
    await WaterManagement.findOne({
      pond: data.pond
    });

  let record;

  if (existing) {
    Object.assign(existing, recordData);
    record = await existing.save();
  } else {
    record =
      await WaterManagement.create(recordData);
  }

  await ActivityLog.create({
    action: existing ? "update" : "create",
    entityType: "WaterManagement",
    entityId: record._id,
    description:
      `Water-management information was ${existing ? "updated" : "recorded"}.`,
    metadata: {
      pondId: record.pond,
      nextWaterChange:
        record.nextWaterChange,
      pumpStatus: record.pumpStatus,
      electricityStatus:
        record.electricityStatus
    },
    ipAddress: ipAddress || "",
    userAgent: userAgent || ""
  });

  return {
    success: true,
    record
  };
};

const listWaterManagement = async ({
  pond,
  status,
  from,
  to,
  page = 1,
  limit = 30
}) => {
  const currentPage = Math.max(
    Number(page) || 1,
    1
  );

  const pageSize = Math.min(
    Math.max(Number(limit) || 30, 1),
    100
  );

  const filter = {};

  if (pond) {
    filter.pond = pond;
  }

  if (from || to) {
    filter.nextWaterChange = {};

    if (from) {
      filter.nextWaterChange.$gte =
        dateStart(from);
    }

    if (to) {
      filter.nextWaterChange.$lte =
        dateEnd(to);
    }
  }

  let records = await populateRecord(
    WaterManagement.find(filter)
      .sort({
        nextWaterChange: 1,
        updatedAt: -1
      })
      .skip((currentPage - 1) * pageSize)
      .limit(pageSize)
      .lean()
  );

  records = records.map((record) => ({
    ...record,
    waterChangeStatus:
      getWaterChangeStatus(
        record.nextWaterChange
      )
  }));

  if (status) {
    records = records.filter(
      (record) =>
        record.waterChangeStatus === status
    );
  }

  const total = status
    ? records.length
    : await WaterManagement.countDocuments(
        filter
      );

  return {
    records,
    pagination: {
      page: currentPage,
      limit: pageSize,
      total,
      pages: Math.ceil(total / pageSize)
    }
  };
};

const getWaterManagementById = async (id) => {
  if (!mongoose.isValidObjectId(id)) {
    return null;
  }

  const record = await populateRecord(
    WaterManagement.findById(id)
  );

  if (!record) {
    return null;
  }

  const plain = record.toObject();

  return {
    ...plain,
    waterChangeStatus:
      getWaterChangeStatus(
        plain.nextWaterChange
      )
  };
};

const updateWaterManagement = async ({
  id,
  data,
  ipAddress,
  userAgent
}) => {
  if (!mongoose.isValidObjectId(id)) {
    return {
      success: false,
      reason: "NOT_FOUND"
    };
  }

  const record =
    await WaterManagement.findById(id);

  if (!record) {
    return {
      success: false,
      reason: "NOT_FOUND"
    };
  }

  if (
    data.pond &&
    !(await validatePond(data.pond))
  ) {
    return {
      success: false,
      reason: "POND_NOT_FOUND"
    };
  }

  const fields = [
    "pond",
    "lastWaterChange",
    "nextWaterChange",
    "waterQualityNotes",
    "pumpStatus",
    "electricityStatus",
    "notes"
  ];

  fields.forEach((field) => {
    if (data[field] !== undefined) {
      record[field] = data[field];
    }
  });

  await record.save();

  await ActivityLog.create({
    action: "update",
    entityType: "WaterManagement",
    entityId: record._id,
    description:
      "Water-management information was updated.",
    metadata: {
      pondId: record.pond,
      nextWaterChange:
        record.nextWaterChange,
      pumpStatus: record.pumpStatus,
      electricityStatus:
        record.electricityStatus
    },
    ipAddress: ipAddress || "",
    userAgent: userAgent || ""
  });

  return {
    success: true,
    record
  };
};

const recordWaterChange = async ({
  id,
  nextWaterChange,
  waterQualityNotes,
  pumpStatus,
  electricityStatus,
  notes,
  ipAddress,
  userAgent
}) => {
  if (!mongoose.isValidObjectId(id)) {
    return {
      success: false,
      reason: "NOT_FOUND"
    };
  }

  const record =
    await WaterManagement.findById(id);

  if (!record) {
    return {
      success: false,
      reason: "NOT_FOUND"
    };
  }

  const previousWaterChange =
    record.lastWaterChange;

  record.lastWaterChange = new Date();

  if (nextWaterChange) {
    record.nextWaterChange =
      new Date(nextWaterChange);
  }

  if (waterQualityNotes !== undefined) {
    record.waterQualityNotes =
      waterQualityNotes;
  }

  if (pumpStatus !== undefined) {
    record.pumpStatus = pumpStatus;
  }

  if (electricityStatus !== undefined) {
    record.electricityStatus =
      electricityStatus;
  }

  if (notes !== undefined) {
    record.notes = notes;
  }

  await record.save();

  await ActivityLog.create({
    action: "water_change",
    entityType: "WaterManagement",
    entityId: record._id,
    description:
      "Water change was recorded.",
    metadata: {
      previousWaterChange,
      newWaterChange:
        record.lastWaterChange,
      nextWaterChange:
        record.nextWaterChange,
      pondId: record.pond
    },
    ipAddress: ipAddress || "",
    userAgent: userAgent || ""
  });

  return {
    success: true,
    record
  };
};

const getWaterChangeSummary = async () => {
  const records =
    await WaterManagement.find({
      nextWaterChange: {
        $ne: null
      }
    })
      .select(
        "pond nextWaterChange pumpStatus electricityStatus"
      )
      .populate(
        "pond",
        "pondName pondNumber status"
      )
      .lean();

  const today = dateStart(new Date());

  let due = 0;
  let overdue = 0;
  let upcoming = 0;
  let pumpAttention = 0;
  let electricityAttention = 0;

  records.forEach((record) => {
    const status =
      getWaterChangeStatus(
        record.nextWaterChange
      );

    if (status === "due") {
      due += 1;
    }

    if (status === "overdue") {
      overdue += 1;
    }

    if (status === "upcoming") {
      upcoming += 1;
    }

    if (
      record.pumpStatus ===
        "needs_attention" ||
      record.pumpStatus === "maintenance"
    ) {
      pumpAttention += 1;
    }

    if (
      record.electricityStatus ===
        "unavailable" ||
      record.electricityStatus === "unstable"
    ) {
      electricityAttention += 1;
    }
  });

  const attentionRecords =
    records.filter((record) => {
      const status =
        getWaterChangeStatus(
          record.nextWaterChange
        );

      return (
        status === "due" ||
        status === "overdue" ||
        record.pumpStatus ===
          "needs_attention" ||
        record.pumpStatus === "maintenance" ||
        record.electricityStatus ===
          "unavailable" ||
        record.electricityStatus ===
          "unstable"
      );
    });

  return {
    total: records.length,
    due,
    overdue,
    upcoming,
    pumpAttention,
    electricityAttention,
    attentionRecords,
    generatedAt: today
  };
};

module.exports = {
  createWaterManagement,
  listWaterManagement,
  getWaterManagementById,
  updateWaterManagement,
  recordWaterChange,
  getWaterChangeSummary,
  getWaterChangeStatus
};