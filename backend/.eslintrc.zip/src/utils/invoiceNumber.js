const crypto = require("crypto");

const Sale = require("../models/Sale");

const pad = (
  value,
  length
) => {
  return String(value)
    .padStart(length, "0");
};

const createCandidate = () => {
  const now = new Date();

  const year =
    now.getFullYear();

  const month =
    pad(
      now.getMonth() + 1,
      2
    );

  const day =
    pad(
      now.getDate(),
      2
    );

  const random =
    crypto
      .randomBytes(3)
      .toString("hex")
      .toUpperCase();

  return `AZF-${year}${month}${day}-${random}`;
};

const generateInvoiceNumber =
  async () => {
    /*
     * MongoDB's unique index on invoiceNumber
     * provides the final database-level
     * protection against duplicates.
     */
    for (let attempt = 0; attempt < 10; attempt += 1) {
      const candidate =
        createCandidate();

      const exists =
        await Sale.exists({
          invoiceNumber:
            candidate
        });

      if (!exists) {
        return candidate;
      }
    }

    /*
     * Extremely unlikely fallback if every
     * random candidate happened to exist.
     */
    return `AZF-${Date.now()}-${crypto
      .randomBytes(4)
      .toString("hex")
      .toUpperCase()}`;
  };

module.exports =
  generateInvoiceNumber;