const {
  body,
  param,
  query
} = require("express-validator");

const pumpStatuses = [
  "operational",
  "needs_attention",
  "maintenance",
  "not_available"
];

const electricityStatuses = [
  "available",
  "unavailable",
  "generator",
  "unstable"
];

const createWaterManagementValidators = [
  body("pond")
    .isMongoId()
    .withMessage("A valid pond is required."),

  body("lastWaterChange")
    .optional({ nullable: true })
    .isISO8601()
    .withMessage("Last water change date must be valid.")
    .toDate(),

  body("nextWaterChange")
    .optional({ nullable: true })
    .isISO8601()
    .withMessage("Next water change date must be valid.")
    .toDate(),

  body("waterQualityNotes")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 3000 })
    .withMessage(
      "Water quality notes cannot exceed 3,000 characters."
    ),

  body("pumpStatus")
    .optional()
    .isIn(pumpStatuses)
    .withMessage("Invalid pump status."),

  body("electricityStatus")
    .optional()
    .isIn(electricityStatuses)
    .withMessage("Invalid electricity status."),

  body("notes")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 2000 })
    .withMessage(
      "Notes cannot exceed 2,000 characters."
    )
];

const updateWaterManagementValidators = [
  param("id")
    .isMongoId()
    .withMessage("Water-management ID must be valid."),

  body("pond")
    .optional()
    .isMongoId()
    .withMessage("Pond must be a valid ID."),

  body("lastWaterChange")
    .optional({ nullable: true })
    .isISO8601()
    .withMessage("Last water change date must be valid.")
    .toDate(),

  body("nextWaterChange")
    .optional({ nullable: true })
    .isISO8601()
    .withMessage("Next water change date must be valid.")
    .toDate(),

  body("waterQualityNotes")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 3000 })
    .withMessage(
      "Water quality notes cannot exceed 3,000 characters."
    ),

  body("pumpStatus")
    .optional()
    .isIn(pumpStatuses)
    .withMessage("Invalid pump status."),

  body("electricityStatus")
    .optional()
    .isIn(electricityStatuses)
    .withMessage("Invalid electricity status."),

  body("notes")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 2000 })
    .withMessage(
      "Notes cannot exceed 2,000 characters."
    )
];

const waterManagementIdValidators = [
  param("id")
    .isMongoId()
    .withMessage(
      "Water-management ID must be valid."
    )
];

const listWaterManagementValidators = [
  query("pond")
    .optional()
    .isMongoId()
    .withMessage("Pond must be a valid ID."),

  query("status")
    .optional()
    .isIn([
      "upcoming",
      "due",
      "overdue"
    ])
    .withMessage("Invalid water-change status."),

  query("from")
    .optional()
    .isISO8601()
    .withMessage("From date must be valid."),

  query("to")
    .optional()
    .isISO8601()
    .withMessage("To date must be valid."),

  query("page")
    .optional()
    .isInt({ min: 1 })
    .withMessage("Page must be at least 1.")
    .toInt(),

  query("limit")
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage(
      "Limit must be between 1 and 100."
    )
    .toInt()
];

module.exports = {
  createWaterManagementValidators,
  updateWaterManagementValidators,
  waterManagementIdValidators,
  listWaterManagementValidators
};