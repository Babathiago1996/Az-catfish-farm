const {
  body,
  param,
  query
} = require("express-validator");

const createMortalityValidators = [
  body("date")
    .isISO8601()
    .withMessage("Mortality date must be valid.")
    .toDate(),

  body("pond")
    .isMongoId()
    .withMessage("A valid pond is required."),

  body("quantity")
    .isInt({ min: 1 })
    .withMessage(
      "Mortality quantity must be at least 1."
    )
    .toInt(),

  body("estimatedCause")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 500 })
    .withMessage(
      "Estimated cause cannot exceed 500 characters."
    ),

  body("notes")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 2000 })
    .withMessage(
      "Notes cannot exceed 2,000 characters."
    ),

  body("imageUrl")
    .optional({ nullable: true })
    .isURL({
      protocols: ["http", "https"],
      require_protocol: true
    })
    .withMessage(
      "Image URL must be a valid URL."
    ),

  body("imagePublicId")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 500 })
    .withMessage(
      "Image public ID cannot exceed 500 characters."
    )
];

const updateMortalityValidators = [
  param("id")
    .isMongoId()
    .withMessage(
      "Mortality record ID must be valid."
    ),

  body("date")
    .optional()
    .isISO8601()
    .withMessage("Mortality date must be valid.")
    .toDate(),

  body("pond")
    .optional()
    .isMongoId()
    .withMessage("Pond must be a valid ID."),

  body("quantity")
    .optional()
    .isInt({ min: 1 })
    .withMessage(
      "Mortality quantity must be at least 1."
    )
    .toInt(),

  body("estimatedCause")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 500 })
    .withMessage(
      "Estimated cause cannot exceed 500 characters."
    ),

  body("notes")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 2000 })
    .withMessage(
      "Notes cannot exceed 2,000 characters."
    ),

  body("imageUrl")
    .optional({ nullable: true })
    .isURL({
      protocols: ["http", "https"],
      require_protocol: true
    })
    .withMessage(
      "Image URL must be a valid URL."
    ),

  body("imagePublicId")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 500 })
    .withMessage(
      "Image public ID cannot exceed 500 characters."
    )
];

const mortalityIdValidators = [
  param("id")
    .isMongoId()
    .withMessage(
      "Mortality record ID must be valid."
    )
];

const listMortalityValidators = [
  query("pond")
    .optional()
    .isMongoId()
    .withMessage("Pond must be a valid ID."),

  query("from")
    .optional()
    .isISO8601()
    .withMessage("From date must be valid."),

  query("to")
    .optional()
    .isISO8601()
    .withMessage("To date must be valid."),

  query("page")
    .optional()
    .isInt({ min: 1 })
    .withMessage("Page must be at least 1.")
    .toInt(),

  query("limit")
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage(
      "Limit must be between 1 and 100."
    )
    .toInt()
];

const mortalitySummaryValidators = [
  query("pond")
    .optional()
    .isMongoId()
    .withMessage("Pond must be a valid ID."),

  query("from")
    .optional()
    .isISO8601()
    .withMessage("From date must be valid."),

  query("to")
    .optional()
    .isISO8601()
    .withMessage("To date must be valid.")
];

module.exports = {
  createMortalityValidators,
  updateMortalityValidators,
  mortalityIdValidators,
  listMortalityValidators,
  mortalitySummaryValidators
};