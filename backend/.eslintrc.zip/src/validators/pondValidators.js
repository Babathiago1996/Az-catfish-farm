const { body, param, query } = require("express-validator");

const objectIdValidation = (fieldName) =>
  param(fieldName)
    .isMongoId()
    .withMessage(`${fieldName} must be a valid ID.`);

const pondNameValidation = body("pondName")
  .trim()
  .notEmpty()
  .withMessage("Pond name is required.")
  .isLength({ max: 100 })
  .withMessage("Pond name cannot exceed 100 characters.");

const pondNumberValidation = body("pondNumber")
  .trim()
  .notEmpty()
  .withMessage("Pond number is required.")
  .isLength({ max: 50 })
  .withMessage("Pond number cannot exceed 50 characters.");

const pondTypeValidation = body("pondType")
  .isIn(["earthen", "concrete", "tarpaulin", "plastic", "other"])
  .withMessage("Invalid pond type.");

const pondSizeValidation = body("pondSize")
  .isFloat({ min: 0 })
  .withMessage("Pond size must be zero or greater.")
  .toFloat();

const waterSourceValidation = body("waterSource")
  .optional({ nullable: true })
  .trim()
  .isLength({ max: 150 })
  .withMessage("Water source cannot exceed 150 characters.");

const statusValidation = body("status")
  .optional()
  .isIn(["active", "empty", "maintenance", "inactive"])
  .withMessage("Invalid pond status.");

const notesValidation = body("notes")
  .optional({ nullable: true })
  .trim()
  .isLength({ max: 2000 })
  .withMessage("Notes cannot exceed 2,000 characters.");

const createPondValidators = [
  pondNameValidation,
  pondNumberValidation,
  pondTypeValidation,
  pondSizeValidation,
  waterSourceValidation,
  statusValidation,
  notesValidation
];

const updatePondValidators = [
  objectIdValidation("id"),

  body("pondName")
    .optional()
    .trim()
    .notEmpty()
    .withMessage("Pond name cannot be empty.")
    .isLength({ max: 100 })
    .withMessage("Pond name cannot exceed 100 characters."),

  body("pondNumber")
    .optional()
    .trim()
    .notEmpty()
    .withMessage("Pond number cannot be empty.")
    .isLength({ max: 50 })
    .withMessage("Pond number cannot exceed 50 characters."),

  body("pondType")
    .optional()
    .isIn(["earthen", "concrete", "tarpaulin", "plastic", "other"])
    .withMessage("Invalid pond type."),

  body("pondSize")
    .optional()
    .isFloat({ min: 0 })
    .withMessage("Pond size must be zero or greater.")
    .toFloat(),

  body("waterSource")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 150 })
    .withMessage("Water source cannot exceed 150 characters."),

  statusValidation,

  notesValidation
];

const pondIdValidators = [
  objectIdValidation("id")
];

const listPondValidators = [
  query("status")
    .optional()
    .isIn(["active", "empty", "maintenance", "inactive"])
    .withMessage("Invalid pond status."),

  query("search")
    .optional()
    .trim()
    .isLength({ max: 100 })
    .withMessage("Search term cannot exceed 100 characters."),

  query("page")
    .optional()
    .isInt({ min: 1 })
    .withMessage("Page must be at least 1.")
    .toInt(),

  query("limit")
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage("Limit must be between 1 and 100.")
    .toInt()
];

module.exports = {
  createPondValidators,
  updatePondValidators,
  pondIdValidators,
  listPondValidators
};