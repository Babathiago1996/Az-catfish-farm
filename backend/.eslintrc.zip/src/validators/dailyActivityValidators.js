const {
  body,
  param,
  query
} = require("express-validator");

const activityTypes = [
  "feeding",
  "water_check",
  "fish_observation",
  "water_change",
  "cleaning",
  "medication",
  "maintenance",
  "harvesting",
  "stocking",
  "sales",
  "other"
];

const periods = [
  "morning",
  "afternoon",
  "evening",
  "other"
];

const statuses = [
  "pending",
  "completed",
  "cancelled"
];

const createDailyActivityValidators = [
  body("date")
    .optional()
    .isISO8601()
    .withMessage("Activity date must be valid.")
    .toDate(),

  body("activityType")
    .isIn(activityTypes)
    .withMessage("Invalid activity type."),

  body("title")
    .trim()
    .notEmpty()
    .withMessage("Activity title is required.")
    .isLength({ max: 150 })
    .withMessage(
      "Activity title cannot exceed 150 characters."
    ),

  body("period")
    .optional()
    .isIn(periods)
    .withMessage("Invalid activity period."),

  body("pond")
    .optional({ nullable: true })
    .isMongoId()
    .withMessage("Pond must be a valid ID."),

  body("notes")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 3000 })
    .withMessage(
      "Activity notes cannot exceed 3,000 characters."
    ),

  body("status")
    .optional()
    .isIn(statuses)
    .withMessage("Invalid activity status.")
];

const updateDailyActivityValidators = [
  param("id")
    .isMongoId()
    .withMessage("Activity ID must be valid."),

  body("date")
    .optional()
    .isISO8601()
    .withMessage("Activity date must be valid.")
    .toDate(),

  body("activityType")
    .optional()
    .isIn(activityTypes)
    .withMessage("Invalid activity type."),

  body("title")
    .optional()
    .trim()
    .notEmpty()
    .withMessage("Activity title cannot be empty.")
    .isLength({ max: 150 })
    .withMessage(
      "Activity title cannot exceed 150 characters."
    ),

  body("period")
    .optional()
    .isIn(periods)
    .withMessage("Invalid activity period."),

  body("pond")
    .optional({ nullable: true })
    .isMongoId()
    .withMessage("Pond must be a valid ID."),

  body("notes")
    .optional({ nullable: true })
    .trim()
    .isLength({ max: 3000 })
    .withMessage(
      "Activity notes cannot exceed 3,000 characters."
    ),

  body("status")
    .optional()
    .isIn(statuses)
    .withMessage("Invalid activity status.")
];

const activityIdValidators = [
  param("id")
    .isMongoId()
    .withMessage("Activity ID must be valid.")
];

const listDailyActivityValidators = [
  query("date")
    .optional()
    .isISO8601()
    .withMessage("Date must be valid."),

  query("from")
    .optional()
    .isISO8601()
    .withMessage("From date must be valid."),

  query("to")
    .optional()
    .isISO8601()
    .withMessage("To date must be valid."),

  query("activityType")
    .optional()
    .isIn(activityTypes)
    .withMessage("Invalid activity type."),

  query("status")
    .optional()
    .isIn(statuses)
    .withMessage("Invalid activity status."),

  query("pond")
    .optional()
    .isMongoId()
    .withMessage("Pond must be a valid ID."),

  query("page")
    .optional()
    .isInt({ min: 1 })
    .withMessage("Page must be at least 1.")
    .toInt(),

  query("limit")
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage(
      "Limit must be between 1 and 100."
    )
    .toInt()
];

module.exports = {
  createDailyActivityValidators,
  updateDailyActivityValidators,
  activityIdValidators,
  listDailyActivityValidators
};