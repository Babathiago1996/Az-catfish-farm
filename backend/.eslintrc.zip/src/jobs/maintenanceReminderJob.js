const cron = require("node-cron");

const maintenanceReminderService = require("../services/maintenanceReminderService");

let scheduledJob = null;

const runMaintenanceReminderJob = async () => {
  try {
    const notifications =
      await maintenanceReminderService.generateMaintenanceNotifications();

    console.log(
      `[Maintenance Reminder] Generated ${notifications.length} notification(s).`
    );

    return notifications;
  } catch (error) {
    console.error(
      "[Maintenance Reminder] Job failed:",
      error.message
    );

    return [];
  }
};

const startMaintenanceReminderJob = () => {
  if (scheduledJob) {
    return scheduledJob;
  }

  /*
   * Runs every morning at 06:00.
   *
   * Africa/Lagos does not observe daylight-saving
   * time, so the farm's reminder schedule remains
   * stable throughout the year.
   */
  scheduledJob = cron.schedule(
    "0 6 * * *",
    runMaintenanceReminderJob,
    {
      scheduled: true,
      timezone: "Africa/Lagos"
    }
  );

  return scheduledJob;
};

const stopMaintenanceReminderJob = () => {
  if (!scheduledJob) {
    return;
  }

  scheduledJob.stop();
  scheduledJob = null;
};

module.exports = {
  startMaintenanceReminderJob,
  stopMaintenanceReminderJob,
  runMaintenanceReminderJob
};