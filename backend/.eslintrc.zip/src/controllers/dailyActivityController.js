const { validationResult } = require("express-validator");

const dailyActivityService = require("../services/dailyActivityService");
const asyncHandler = require("../utils/asyncHandler");

const {
  successResponse,
  errorResponse
} = require("../utils/apiResponse");

const metadata = (req) => ({
  ipAddress:
    req.ip ||
    req.headers["x-forwarded-for"] ||
    req.socket?.remoteAddress ||
    "",

  userAgent: req.get("user-agent") || ""
});

const validate = (req, res) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    errorResponse(res, {
      statusCode: 422,
      message: "Please correct the highlighted fields.",
      errors: errors.array().map((error) => ({
        field: error.path,
        message: error.msg
      }))
    });

    return false;
  }

  return true;
};

const createActivity = asyncHandler(
  async (req, res) => {
    if (!validate(req, res)) {
      return;
    }

    const result =
      await dailyActivityService.createActivity({
        data: req.body,
        ...metadata(req)
      });

    if (!result.success) {
      return errorResponse(res, {
        statusCode:
          result.reason === "POND_NOT_FOUND"
            ? 404
            : 400,
        message:
          result.reason === "POND_NOT_FOUND"
            ? "The selected pond was not found."
            : "Unable to create farm activity."
      });
    }

    return successResponse(res, {
      statusCode: 201,
      message: "Farm activity created successfully.",
      data: {
        activity: result.activity
      }
    });
  }
);

const listActivities = asyncHandler(
  async (req, res) => {
    if (!validate(req, res)) {
      return;
    }

    const result =
      await dailyActivityService.listActivities({
        date: req.query.date,
        from: req.query.from,
        to: req.query.to,
        activityType: req.query.activityType,
        status: req.query.status,
        pond: req.query.pond,
        page: req.query.page,
        limit: req.query.limit
      });

    return successResponse(res, {
      statusCode: 200,
      message:
        "Farm activities retrieved successfully.",
      data: result
    });
  }
);

const getActivity = asyncHandler(
  async (req, res) => {
    if (!validate(req, res)) {
      return;
    }

    const activity =
      await dailyActivityService.getActivityById(
        req.params.id
      );

    if (!activity) {
      return errorResponse(res, {
        statusCode: 404,
        message: "Farm activity not found."
      });
    }

    return successResponse(res, {
      statusCode: 200,
      message:
        "Farm activity retrieved successfully.",
      data: {
        activity
      }
    });
  }
);

const updateActivity = asyncHandler(
  async (req, res) => {
    if (!validate(req, res)) {
      return;
    }

    const result =
      await dailyActivityService.updateActivity({
        activityId: req.params.id,
        data: req.body,
        ...metadata(req)
      });

    if (!result.success) {
      const response =
        result.reason === "ACTIVITY_NOT_FOUND"
          ? {
              statusCode: 404,
              message: "Farm activity not found."
            }
          : result.reason === "POND_NOT_FOUND"
          ? {
              statusCode: 404,
              message:
                "The selected pond was not found."
            }
          : {
              statusCode: 400,
              message:
                "Unable to update farm activity."
            };

      return errorResponse(res, response);
    }

    return successResponse(res, {
      statusCode: 200,
      message: "Farm activity updated successfully.",
      data: {
        activity: result.activity
      }
    });
  }
);

const deleteActivity = asyncHandler(
  async (req, res) => {
    if (!validate(req, res)) {
      return;
    }

    const result =
      await dailyActivityService.deleteActivity({
        activityId: req.params.id,
        ...metadata(req)
      });

    if (!result.success) {
      return errorResponse(res, {
        statusCode: 404,
        message: "Farm activity not found."
      });
    }

    return successResponse(res, {
      statusCode: 200,
      message: "Farm activity deleted successfully."
    });
  }
);

module.exports = {
  createActivity,
  listActivities,
  getActivity,
  updateActivity,
  deleteActivity
};