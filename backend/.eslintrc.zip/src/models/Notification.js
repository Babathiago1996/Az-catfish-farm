const mongoose = require("mongoose");

const notificationSchema = new mongoose.Schema(
  {
    type: {
      type: String,
      required: [true, "Notification type is required."],
      enum: [
        "water_change_due",
        "water_change_overdue",
        "feeding_time",
        "harvest_near",
        "feed_running_low",
        "inventory_running_low",
        "pond_needs_attention",
        "weekly_growth_recording",
        "monthly_report_ready",
        "pump_maintenance",
        "generator_maintenance",
        "new_contact_message",
        "system"
      ],
      index: true
    },

    title: {
      type: String,
      required: [true, "Notification title is required."],
      trim: true,
      maxlength: 200
    },

    message: {
      type: String,
      required: [true, "Notification message is required."],
      trim: true,
      maxlength: 1000
    },

    entityType: {
      type: String,
      default: "",
      trim: true,
      maxlength: 100
    },

    entityId: {
      type: mongoose.Schema.Types.ObjectId,
      default: null
    },

    actionUrl: {
      type: String,
      default: "",
      trim: true,
      maxlength: 500
    },

    isRead: {
      type: Boolean,
      default: false,
      index: true
    },

    readAt: {
      type: Date,
      default: null
    },

    isDeleted: {
      type: Boolean,
      default: false,
      index: true
    },

    deletedAt: {
      type: Date,
      default: null
    },

    expiresAt: {
      type: Date,
      default: null,
      index: true
    }
  },
  {
    timestamps: true,
    versionKey: false
  }
);

notificationSchema.index({
  createdAt: -1,
  isRead: 1,
  isDeleted: 1
});

module.exports = mongoose.model(
  "Notification",
  notificationSchema
);