const mongoose = require("mongoose");

const saleSchema = new mongoose.Schema(
  {
    invoiceNumber: {
      type: String,
      required: [true, "Invoice number is required."],
      unique: true,
      trim: true,
      uppercase: true,
      index: true
    },

    saleDate: {
      type: Date,
      required: [true, "Sale date is required."],
      default: Date.now,
      index: true
    },

    pond: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Pond",
      default: null,
      index: true
    },

    customerName: {
      type: String,
      required: [true, "Customer name is required."],
      trim: true,
      maxlength: 150
    },

    phoneNumber: {
      type: String,
      default: "",
      trim: true,
      maxlength: 50
    },

    quantitySold: {
      type: Number,
      required: [true, "Quantity sold is required."],
      min: [1, "Quantity sold must be at least 1."]
    },

    averageWeight: {
      type: Number,
      required: [true, "Average weight is required."],
      min: 0
    },

    pricePerKilogram: {
      type: Number,
      required: [true, "Price per kilogram is required."],
      min: 0
    },

    totalWeight: {
      type: Number,
      required: [true, "Total weight is required."],
      min: 0
    },

    totalAmount: {
      type: Number,
      required: [true, "Total amount is required."],
      min: 0
    },

    paymentStatus: {
      type: String,
      enum: ["paid", "partial", "pending", "cancelled"],
      default: "pending",
      index: true
    },

    amountPaid: {
      type: Number,
      default: 0,
      min: 0
    },

    balanceDue: {
      type: Number,
      default: 0,
      min: 0
    },

    paymentMethod: {
      type: String,
      enum: [
        "cash",
        "bank_transfer",
        "pos",
        "mobile_money",
        "other"
      ],
      default: "cash"
    },

    notes: {
      type: String,
      default: "",
      trim: true,
      maxlength: 2000
    }
  },
  {
    timestamps: true,
    versionKey: false
  }
);

saleSchema.index({
  saleDate: -1,
  paymentStatus: 1
});

saleSchema.index({
  customerName: "text",
  invoiceNumber: "text",
  phoneNumber: "text"
});

module.exports = mongoose.model("Sale", saleSchema);