const mongoose = require("mongoose");

const adminSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: [true, "Administrator email is required."],
      unique: true,
      lowercase: true,
      trim: true,
      index: true,
      match: [
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        "Please provide a valid administrator email."
      ]
    },

    password: {
      type: String,
      required: [true, "Administrator password is required."],
      minlength: [8, "Password must contain at least 8 characters."],
      select: false
    },

    passwordChangedAt: {
      type: Date,
      default: null
    },

    resetPasswordTokenHash: {
      type: String,
      default: null,
      select: false
    },

    resetPasswordExpiresAt: {
      type: Date,
      default: null,
      select: false
    },

    lastLoginAt: {
      type: Date,
      default: null
    },

    isActive: {
      type: Boolean,
      default: true,
      index: true
    }
  },
  {
    timestamps: true,
    versionKey: false
  }
);

adminSchema.methods.toSafeObject = function toSafeObject() {
  return {
    id: this._id.toString(),
    email: this.email,
    lastLoginAt: this.lastLoginAt,
    isActive: this.isActive,
    createdAt: this.createdAt,
    updatedAt: this.updatedAt
  };
};

module.exports = mongoose.model("Admin", adminSchema);