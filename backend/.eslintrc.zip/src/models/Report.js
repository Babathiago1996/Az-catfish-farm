const mongoose = require("mongoose");

const reportSchema = new mongoose.Schema(
  {
    reportType: {
      type: String,
      required: [true, "Report type is required."],
      enum: ["daily", "weekly", "monthly", "yearly"],
      index: true
    },

    periodStart: {
      type: Date,
      required: [true, "Report period start is required."],
      index: true
    },

    periodEnd: {
      type: Date,
      required: [true, "Report period end is required."],
      index: true
    },

    format: {
      type: String,
      required: [true, "Report format is required."],
      enum: ["pdf", "xlsx", "csv"],
      lowercase: true
    },

    fileName: {
      type: String,
      required: [true, "Report file name is required."],
      trim: true
    },

    filePath: {
      type: String,
      default: "",
      trim: true
    },

    downloadUrl: {
      type: String,
      default: "",
      trim: true
    },

    summary: {
      totalFish: {
        type: Number,
        default: 0,
        min: 0
      },

      totalSales: {
        type: Number,
        default: 0,
        min: 0
      },

      totalExpenses: {
        type: Number,
        default: 0,
        min: 0
      },

      netProfit: {
        type: Number,
        default: 0
      },

      totalMortality: {
        type: Number,
        default: 0,
        min: 0
      },

      totalFeedConsumed: {
        type: Number,
        default: 0,
        min: 0
      }
    },

    generatedAt: {
      type: Date,
      default: Date.now,
      index: true
    },

    expiresAt: {
      type: Date,
      default: null,
      index: true
    }
  },
  {
    timestamps: true,
    versionKey: false
  }
);

reportSchema.index({
  reportType: 1,
  periodStart: -1,
  periodEnd: -1
});

module.exports = mongoose.model("Report", reportSchema);