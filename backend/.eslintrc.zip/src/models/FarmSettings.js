const mongoose = require("mongoose");

const socialLinksSchema = new mongoose.Schema(
  {
    facebook: {
      type: String,
      default: "",
      trim: true
    },

    instagram: {
      type: String,
      default: "",
      trim: true
    },

    whatsapp: {
      type: String,
      default: "",
      trim: true
    },

    tiktok: {
      type: String,
      default: "",
      trim: true
    },

    youtube: {
      type: String,
      default: "",
      trim: true
    },

    twitter: {
      type: String,
      default: "",
      trim: true
    }
  },
  {
    _id: false
  }
);

const feedingScheduleSchema = new mongoose.Schema(
  {
    morning: {
      enabled: {
        type: Boolean,
        default: true
      },
      time: {
        type: String,
        default: "08:00",
        trim: true
      }
    },

    afternoon: {
      enabled: {
        type: Boolean,
        default: false
      },
      time: {
        type: String,
        default: "14:00",
        trim: true
      }
    },

    evening: {
      enabled: {
        type: Boolean,
        default: true
      },
      time: {
        type: String,
        default: "18:00",
        trim: true
      }
    }
  },
  {
    _id: false
  }
);

const notificationPreferencesSchema = new mongoose.Schema(
  {
    emailNotifications: {
      type: Boolean,
      default: true
    },

    inAppNotifications: {
      type: Boolean,
      default: true
    },

    waterChangeReminders: {
      type: Boolean,
      default: true
    },

    feedingReminders: {
      type: Boolean,
      default: true
    },

    growthReminders: {
      type: Boolean,
      default: true
    },

    harvestReminders: {
      type: Boolean,
      default: true
    },

    inventoryAlerts: {
      type: Boolean,
      default: true
    },

    monthlyReportNotifications: {
      type: Boolean,
      default: true
    }
  },
  {
    _id: false
  }
);

const smtpSettingsSchema = new mongoose.Schema(
  {
    host: {
      type: String,
      default: "",
      trim: true
    },

    port: {
      type: Number,
      default: 587,
      min: 1,
      max: 65535
    },

    secure: {
      type: Boolean,
      default: false
    },

    username: {
      type: String,
      default: "",
      trim: true
    },

    password: {
      type: String,
      default: "",
      select: false
    },

    fromName: {
      type: String,
      default: "AZ Fish Farm",
      trim: true
    },

    fromEmail: {
      type: String,
      default: "",
      trim: true,
      lowercase: true
    }
  },
  {
    _id: false
  }
);

const cloudinarySettingsSchema = new mongoose.Schema(
  {
    cloudName: {
      type: String,
      default: "",
      trim: true
    },

    apiKey: {
      type: String,
      default: "",
      trim: true
    },

    apiSecret: {
      type: String,
      default: "",
      select: false
    }
  },
  {
    _id: false
  }
);

const farmSettingsSchema = new mongoose.Schema(
  {
    singletonKey: {
      type: String,
      default: "default",
      unique: true,
      immutable: true,
      index: true
    },

    farmName: {
      type: String,
      required: [true, "Farm name is required."],
      default: "AZ Fish Farm",
      trim: true,
      maxlength: 150
    },

    farmLogo: {
      url: {
        type: String,
        default: "",
        trim: true
      },
      publicId: {
        type: String,
        default: "",
        trim: true
      }
    },

    email: {
      type: String,
      default: "",
      trim: true,
      lowercase: true
    },

    phone: {
      type: String,
      default: "",
      trim: true,
      maxlength: 50
    },

    address: {
      type: String,
      default: "",
      trim: true,
      maxlength: 500
    },

    about: {
      type: String,
      default: "",
      trim: true,
      maxlength: 5000
    },

    socialLinks: {
      type: socialLinksSchema,
      default: () => ({})
    },

    smtp: {
      type: smtpSettingsSchema,
      default: () => ({})
    },

    cloudinary: {
      type: cloudinarySettingsSchema,
      default: () => ({})
    },

    waterChangeIntervalDays: {
      type: Number,
      default: 7,
      min: 1,
      max: 365
    },

    feedingSchedule: {
      type: feedingScheduleSchema,
      default: () => ({})
    },

    notificationPreferences: {
      type: notificationPreferencesSchema,
      default: () => ({})
    }
  },
  {
    timestamps: true,
    versionKey: false
  }
);

module.exports = mongoose.model("FarmSettings", farmSettingsSchema);