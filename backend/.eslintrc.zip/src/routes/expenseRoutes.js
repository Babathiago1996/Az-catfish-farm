const express = require("express");

const {
  protect
} = require("../middleware/authMiddleware");

const controller =
  require("../controllers/expenseController");

const {
  createExpenseValidators,
  updateExpenseValidators,
  expenseIdValidators,
  listExpenseValidators,
  expenseSummaryValidators
} = require("../validators/expenseValidators");

const router =
  express.Router();

router.use(protect);

router.get(
  "/summary",
  expenseSummaryValidators,
  controller.getExpenseSummary
);

router.get(
  "/",
  listExpenseValidators,
  controller.listExpenses
);

router.post(
  "/",
  createExpenseValidators,
  controller.createExpense
);

router.get(
  "/:id",
  expenseIdValidators,
  controller.getExpense
);

router.patch(
  "/:id",
  updateExpenseValidators,
  controller.updateExpense
);

router.delete(
  "/:id",
  expenseIdValidators,
  controller.deleteExpense
);

module.exports = router;