const express = require("express");

const {
  protect
} = require("../middleware/authMiddleware");

const controller = require("../controllers/feedingController");

const {
  createFeedingValidators,
  feedingIdValidators,
  listFeedingValidators
} = require("../validators/feedingValidators");

const router = express.Router();

router.use(protect);

router.get(
  "/today",
  controller.getTodayConsumption
);

router.get(
  "/",
  listFeedingValidators,
  controller.listFeedings
);

router.post(
  "/",
  createFeedingValidators,
  controller.createFeeding
);

router.get(
  "/:id",
  feedingIdValidators,
  controller.getFeeding
);

module.exports = router;