const express = require("express");

const {
  protect
} = require("../middleware/authMiddleware");

const controller = require("../controllers/saleController");

const {
  createSaleValidators,
  updateSaleValidators,
  saleIdValidators,
  listSaleValidators,
  salesSummaryValidators
} = require("../validators/saleValidators");

const router = express.Router();

router.use(protect);

router.get(
  "/summary",
  salesSummaryValidators,
  controller.getSalesSummary
);

router.get(
  "/",
  listSaleValidators,
  controller.listSales
);

router.post(
  "/",
  createSaleValidators,
  controller.createSale
);

router.get(
  "/:id",
  saleIdValidators,
  controller.getSale
);

router.patch(
  "/:id",
  updateSaleValidators,
  controller.updateSale
);

module.exports = router;