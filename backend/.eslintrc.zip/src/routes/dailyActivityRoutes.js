const express = require("express");

const {
  protect
} = require("../middleware/authMiddleware");

const controller = require("../controllers/dailyActivityController");

const {
  createDailyActivityValidators,
  updateDailyActivityValidators,
  activityIdValidators,
  listDailyActivityValidators
} = require("../validators/dailyActivityValidators");

const router = express.Router();

router.use(protect);

router.get(
  "/",
  listDailyActivityValidators,
  controller.listActivities
);

router.post(
  "/",
  createDailyActivityValidators,
  controller.createActivity
);

router.get(
  "/:id",
  activityIdValidators,
  controller.getActivity
);

router.patch(
  "/:id",
  updateDailyActivityValidators,
  controller.updateActivity
);

router.delete(
  "/:id",
  activityIdValidators,
  controller.deleteActivity
);

module.exports = router;