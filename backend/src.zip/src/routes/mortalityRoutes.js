const express = require("express");

const {
  protect,
} = require("../middleware/authMiddleware");

const controller =
  require("../controllers/mortalityController");

const {
  createMortalityValidators,
  updateMortalityValidators,
  mortalityIdValidators,
  listMortalityValidators,
  mortalitySummaryValidators,
} = require("../validators/mortalityValidators");

const router = express.Router();

/*
 * All mortality endpoints require
 * administrator authentication.
 */
router.use(protect);

/*
 * Summary
 *
 * GET /api/mortality/summary
 */
router.get(
  "/summary",
  mortalitySummaryValidators,
  controller.getMortalitySummary,
);

/*
 * List
 *
 * GET /api/mortality
 */
router.get(
  "/",
  listMortalityValidators,
  controller.listMortality,
);

/*
 * Create
 *
 * POST /api/mortality
 */
router.post(
  "/",
  createMortalityValidators,
  controller.createMortality,
);

/*
 * Get one
 *
 * GET /api/mortality/:id
 */
router.get(
  "/:id",
  mortalityIdValidators,
  controller.getMortality,
);

/*
 * Update
 *
 * PATCH /api/mortality/:id
 */
router.patch(
  "/:id",
  updateMortalityValidators,
  controller.updateMortality,
);

module.exports = router;